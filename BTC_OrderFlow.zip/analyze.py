import datetime as dt, json, os, statistics
from btcof import db, orderflow, sources, schema
from btcof.config import CFG
conn = db.connect(CFG.path(CFG.db_path))
DAYS = ["2026-10-20","2026-10-21","2026-10-22","2026-10-23","2026-10-24","2026-10-25",
        "2026-10-26","2026-10-27","2026-10-29","2026-10-30","2026-10-31"]
FIELDS = ["open","high","low","close","volume","taker_buy"]
acc = {f: {"abs":[], "pct":[]} for f in FIELDS}
per_day = {}
oct27 = {"bars":0,"vol_ours":0.0,"vol_ref":0.0,"worst":None}
rows_out = []
for s in DAYS:
    d = dt.date.fromisoformat(s)
    ref = sources.parse_kline_zip(CFG.path("%s/BTCUSDT-30m-%s.zip" % (CFG.raw_dir, s)))
    start = ref[0]["open_time"]
    bars = orderflow.build_bars(conn,"BTCUSDT",30,start_ms=start,end_ms=start+86400000,
                                big_qty=CFG.big_qty, with_annotations=False)
    mine = {b.open_time: b for b in bars}
    day = {"bars":0,"exact_price":0,"vol_abs":0.0,"vol_pct":0.0,"tb_abs":0.0,"tb_pct":0.0}
    for r in ref:
        b = mine.get(r["open_time"])
        if b is None: continue
        day["bars"] += 1
        vals = {"open":b.open,"high":b.high,"low":b.low,"close":b.close,
                "volume":b.volume,"taker_buy":b.buy_vol}
        rev  = {"open":r["open"],"high":r["high"],"low":r["low"],"close":r["close"],
                "volume":r["volume"],"taker_buy":r["taker_buy_volume"]}
        for f in FIELDS:
            a = abs(vals[f]-rev[f]); p = (a/abs(rev[f])*100) if rev[f] else 0.0
            acc[f]["abs"].append(a); acc[f]["pct"].append(p)
        if max(abs(vals["open"]-rev["open"]),abs(vals["high"]-rev["high"]),
               abs(vals["low"]-rev["low"]),abs(vals["close"]-rev["close"])) == 0:
            day["exact_price"] += 1
        if s == "2026-10-27":
            oct27["bars"] += 1; oct27["vol_ours"] += vals["volume"]; oct27["vol_ref"] += rev["volume"]
            if oct27["worst"] is None or abs(vals["volume"]-rev["volume"]) > oct27["worst"]["abs"]:
                oct27["worst"] = {"open_time":r["open_time"],"ours":vals["volume"],
                                  "ref":rev["volume"],"abs":abs(vals["volume"]-rev["volume"])}
    per_day[s] = day
# aggregate excludes 10-27 for the headline, and gives it separately
def summarise(exclude=("2026-10-27",)):
    out={}
    for f in FIELDS:
        out[f]={}
    # recompute excluding a day by rebuilding lists
    out={f:{"abs":[],"pct":[]} for f in FIELDS}
    for s in DAYS:
        if s in exclude: continue
        ref = sources.parse_kline_zip(CFG.path("%s/BTCUSDT-30m-%s.zip" % (CFG.raw_dir, s)))
        start = ref[0]["open_time"]
        bars = orderflow.build_bars(conn,"BTCUSDT",30,start_ms=start,end_ms=start+86400000,
                                    big_qty=CFG.big_qty, with_annotations=False)
        mine = {b.open_time: b for b in bars}
        for r in ref:
            b = mine.get(r["open_time"])
            if b is None: continue
            vals = {"open":b.open,"high":b.high,"low":b.low,"close":b.close,
                    "volume":b.volume,"taker_buy":b.buy_vol}
            rev  = {"open":r["open"],"high":r["high"],"low":r["low"],"close":r["close"],
                    "volume":r["volume"],"taker_buy":r["taker_buy_volume"]}
            for f in FIELDS:
                a = abs(vals[f]-rev[f]); p = (a/abs(rev[f])*100) if rev[f] else 0.0
                out[f]["abs"].append(a); out[f]["pct"].append(p)
    return {f:{"n":len(out[f]["abs"]),
               "max_abs":round(max(out[f]["abs"]),6),
               "mean_abs":round(statistics.mean(out[f]["abs"]),8),
               "max_pct":round(max(out[f]["pct"]),8),
               "mean_pct":round(statistics.mean(out[f]["pct"]),8),
               "within_0.1pct":sum(1 for x in out[f]["pct"] if x<=0.1),
               "within_0.001pct":sum(1 for x in out[f]["pct"] if x<=0.001)} for f in FIELDS}

print("=== PER-FIELD MATCH, 480 bars (all days EXCEPT 2026-10-27) ===")
ex = summarise()
for f in FIELDS:
    x = ex[f]
    print("  %-10s n=%d max_abs=%.4f mean_abs=%.6f max_pct=%.6f%% mean_pct=%.6f%% within0.001%%=%d"
          % (f,x["n"],x["max_abs"],x["mean_abs"],x["max_pct"],x["mean_pct"],x["within_0.001pct"]))
print("\n=== 2026-10-27 (48 bars) ===")
print("  volume ours=%.3f kline=%.3f  deficit=%.3f BTC" % (oct27["vol_ours"],oct27["vol_ref"],oct27["vol_ref"]-oct27["vol_ours"]))
print("  worst bar: ours=%.3f ref=%.3f abs=%.3f" % (oct27["worst"]["ours"],oct27["worst"]["ref"],oct27["worst"]["abs"]))
print("\n=== per-day ===")
for s in DAYS:
    x=per_day[s]; print("  %s bars=%d exact_price=%d" % (s,x["bars"],x["exact_price"]))

# CVD rebuild vs stored
full = orderflow.build_bars(conn,"BTCUSDT",30,big_qty=CFG.big_qty,with_annotations=False)
stored = {r["open_time"]: r for r in conn.execute("SELECT open_time,cvd_close,delta FROM bars WHERE symbol='BTCUSDT' AND tf_minutes=30")}
diff = [(b.open_time, b.cvd_close, stored[b.open_time]["cvd_close"]) for b in full
        if b.open_time in stored and abs(b.cvd_close-stored[b.open_time]["cvd_close"])>1e-9]
print("\n=== CVD rebuild vs stored: bars=%d mismatches=%d final=%.4f ===" % (len(full),len(diff),full[-1].cvd_close))
# fake bars check
empty = conn.execute("SELECT COUNT(*) c FROM bars WHERE symbol='BTCUSDT' AND tf_minutes=30 AND (volume=0 OR agg_trades=0)").fetchone()["c"]
print("zero-volume / fake bars in table:", empty)
rep = {"per_field_excluding_oct27": ex, "oct27": oct27, "per_day": per_day,
       "cvd_rebuild_final": full[-1].cvd_close, "cvd_mismatches": len(diff),
       "fake_bars": empty, "bars_total": len(full)}
os.makedirs(CFG.path("reports"), exist_ok=True)
json.dump(rep, open(CFG.path("reports/bar_match_report.json"),"w"), indent=2)
print("\nsaved reports/bar_match_report.json")

#!/usr/bin/env python3
from btcof.run import main

if __name__ == "__main__":
    main()

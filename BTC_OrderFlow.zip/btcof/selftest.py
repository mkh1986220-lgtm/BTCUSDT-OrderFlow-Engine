"""Test suite. Run with:  python -m btcof.selftest

Each test states what it proves. Tests that need a live endpoint are marked and
skipped with a reason instead of being reported as passing.
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import tempfile
import unittest
import zipfile

from . import cvd, db, gaps, orderflow, schema, sources, stream
from .config import CFG

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TF = 30
TF_MS = TF * 60_000
B0 = 1_700_000_000_000 - (1_700_000_000_000 % TF_MS)


def make_zip(path, rows, header=True, columns=None):
    columns = columns or list(schema.AGG_COLUMNS)
    lines = []
    if header:
        lines.append(",".join(columns))
    for r in rows:
        lines.append(",".join(str(x) for x in r))
    with zipfile.ZipFile(path, "w") as z:
        z.writestr(os.path.basename(path).replace(".zip", ".csv"),
                   "\n".join(lines) + "\n")
    return path


def csv_row(agg_id, ts, price, qty, ftid, ltid, m):
    # order matches the documented archive columns
    return (agg_id, price, qty, ftid, ltid, ts, "true" if m else "false")


class TmpDB(object):
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="btcof_test_")
        self.path = os.path.join(self.dir, "t.db")
        self.conn = db.connect(self.path)

    def close(self):
        try:
            self.conn.close()
        finally:
            shutil.rmtree(self.dir, ignore_errors=True)


def seed(conn, rows, symbol=None):
    return db.insert_rows(conn, symbol or CFG.symbol, rows)


# ---------------------------------------------------------------------------
class TestArchiveParsing(unittest.TestCase):
    """1-3: real ZIP, header extraction, column contract."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="btcof_zip_")

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_real_zip_header_and_rows(self):
        raw = CFG.path(CFG.raw_dir)
        cands = [f for f in os.listdir(raw) if f.endswith(".zip")
                 and "aggTrades" in f] if os.path.isdir(raw) else []
        if not cands:
            self.skipTest("no real archive in data/raw (download one first)")
        path = os.path.join(raw, sorted(cands)[0])
        f = sources.AggArchiveFile(path)
        it = iter(f)
        first = next(it)
        self.assertEqual(f.header, list(schema.AGG_COLUMNS))
        self.assertEqual(len(first), 7)
        self.assertEqual(f.unit, "ms")
        self.assertGreater(first[2], 1000)     # price
        self.assertGreater(first[3], 0)        # qty
        self.assertGreater(first[1], 10 ** 12)  # ts in ms
        self.assertIn(first[6], (0, 1))
        n = 1
        for _ in it:
            n += 1
            if n >= 2000:
                break
        self.assertEqual(n, 2000)
        st = f.stats()
        self.assertEqual(st["rows"], 2000)

    def test_header_maps_by_name_not_position(self):
        """A file whose columns are physically reordered must still parse
        correctly, because we look columns up by name."""
        cols = list(schema.AGG_COLUMNS)
        swapped = cols[:]
        swapped[1], swapped[2] = swapped[2], swapped[1]   # price<->quantity
        canonical = csv_row(1, B0, 100.0, 2.0, 10, 10, False)
        by_name = dict(zip(cols, canonical))
        # write the values IN THE ORDER THE HEADER DECLARES
        reordered = tuple(by_name[c] for c in swapped)
        path = os.path.join(self.tmp, "swapped.zip")
        make_zip(path, [reordered], columns=swapped)
        f = sources.AggArchiveFile(path)
        row = next(iter(f))
        self.assertAlmostEqual(row[2], 100.0)   # price still 100
        self.assertAlmostEqual(row[3], 2.0)     # qty still 2

    def test_wrong_column_contract_raises(self):
        path = os.path.join(self.tmp, "bad.zip")
        make_zip(path, [(1, 100.0, 2.0, 10, 10, B0, "false")],
                 columns=["a", "b", "c", "d", "e", "f", "g"])
        with self.assertRaises(schema.SchemaError):
            list(sources.AggArchiveFile(path))

    def test_short_row_raises(self):
        path = os.path.join(self.tmp, "short.zip")
        with zipfile.ZipFile(path, "w") as z:
            z.writestr("x.csv", "agg_trade_id,price,quantity,first_trade_id,"
                                "last_trade_id,transact_time,is_buyer_maker\n"
                                "1,100.0,2.0\n")
        with self.assertRaises(schema.SchemaError):
            list(sources.AggArchiveFile(path))


class TestTimestampUnits(unittest.TestCase):
    """4: unit detection and normalisation."""

    def test_detection(self):
        self.assertEqual(schema.detect_ts_unit(1793318400), "s")
        self.assertEqual(schema.detect_ts_unit(1793318400000), "ms")
        self.assertEqual(schema.detect_ts_unit(1793318400000000), "us")
        self.assertEqual(schema.detect_ts_unit(1793318400000000000), "ns")

    def test_normalisation_preserves_ms(self):
        ms = 1793318400050
        for unit in ("ms", "us", "ns"):
            raw = {"ms": ms, "us": ms * 1000, "ns": ms * 1000000}[unit]
            self.assertEqual(schema.to_ms(raw, schema.detect_ts_unit(raw)), ms)

    def test_rest_row_normalises_microseconds(self):
        obj = {"a": 1, "p": "100.5", "q": "0.25", "f": 1, "l": 1,
               "T": 1793318400050000, "m": True}
        row = schema.row_from_rest(obj, require_trade_ids=True)
        self.assertEqual(row[1], 1793318400050)


class TestRestParsing(unittest.TestCase):
    """REST/WS payload is read by key; order and string numbers must not matter."""

    def test_keyed_access_any_order(self):
        payload = {"m": False, "T": 1793318400050, "q": "0.5",
                   "p": "77000.1", "l": 9, "f": 8, "a": 42, "e": "aggTrade"}
        row = schema.row_from_rest(payload, require_trade_ids=True)
        self.assertEqual(row[0], 42)
        self.assertEqual(row[1], 1793318400050)
        self.assertAlmostEqual(row[2], 77000.1)
        self.assertAlmostEqual(row[3], 0.5)
        self.assertEqual((row[4], row[5]), (8, 9))
        self.assertEqual(row[6], 0)

    def test_missing_key_raises(self):
        with self.assertRaises(schema.SchemaError):
            schema.row_from_rest({"a": 1, "p": "1", "q": "1", "m": False})

    def test_ws_invalid_json_is_handled(self):
        with self.assertRaises(ValueError):
            stream.parse_ws_message("{not json")

    def test_ws_non_aggtrade_returns_none(self):
        self.assertIsNone(stream.parse_ws_message(
            json.dumps({"e": "markPriceUpdate", "p": "1"})))


class TestAggregation(unittest.TestCase):
    """7-9: buy/sell volume, delta, delta%, CVD, duplicates, trade counts."""

    def setUp(self):
        self.t = TmpDB()

    def tearDown(self):
        self.t.close()

    def _bars(self, rows, tf=TF):
        seed(self.t.conn, rows)
        return orderflow.build_bars(self.t.conn, CFG.symbol, tf,
                                    big_qty=CFG.big_qty, with_annotations=False)

    def test_buy_sell_delta_cvd(self):
        rows = [(i + 1, B0 + i * 10, 100.0, 1.0, i + 1, i + 1, 0)
                for i in range(10)]                       # 10 buys x 1
        rows += [(11 + i, B0 + 200 + i * 10, 100.0, 1.0, 11 + i, 11 + i, 1)
                 for i in range(4)]                       # 4 sells x 1
        bars = self._bars(rows)
        b = bars[0]
        self.assertAlmostEqual(b.volume, 14.0)
        self.assertAlmostEqual(b.buy_vol, 10.0)
        self.assertAlmostEqual(b.sell_vol, 4.0)
        self.assertAlmostEqual(b.delta, 6.0)
        self.assertAlmostEqual(b.delta_pct, 6.0 / 14.0 * 100)
        self.assertAlmostEqual(b.cvd_close, 6.0)
        self.assertEqual(b.agg_trades, 14)
        self.assertEqual(b.trades, 14)

    def test_duplicates_are_rejected(self):
        rows = [(i + 1, B0 + i * 10, 100.0, 1.0, i + 1, i + 1, 0) for i in range(5)]
        first = seed(self.t.conn, rows)
        second = seed(self.t.conn, rows)
        self.assertEqual(first["inserted"], 5)
        self.assertEqual(second["inserted"], 0)
        self.assertEqual(second["dupes"], 5)
        self.assertEqual(second["conflicts"], 0)
        n = self.t.conn.execute("SELECT COUNT(*) c FROM agg_trades").fetchone()["c"]
        self.assertEqual(n, 5)

    def test_conflicting_duplicate_is_flagged(self):
        seed(self.t.conn, [(1, B0, 100.0, 1.0, 1, 1, 0)])
        res = seed(self.t.conn, [(1, B0, 101.0, 1.0, 1, 1, 0)])   # same id, other price
        self.assertEqual(res["inserted"], 0)
        self.assertEqual(res["conflicts"], 1)

    def test_trade_id_gap_counted(self):
        rows = [(1, B0, 100.0, 1.0, 1, 5, 0),
                (2, B0 + 10, 100.0, 1.0, 9, 9, 0)]   # 6,7,8 missing
        seed(self.t.conn, rows)
        row = self.t.conn.execute(
            "SELECT SUM(last_tid-first_tid+1) t FROM agg_trades").fetchone()
        self.assertEqual(row["t"], 6)                # 5 + 1, not 8
        bars = orderflow.build_bars(self.t.conn, CFG.symbol, TF,
                                    with_annotations=False)
        self.assertEqual(bars[0].trades, 6)
        self.assertEqual(bars[0].agg_trades, 2)

    def test_cvd_carries_across_bars(self):
        rows = [(1, B0, 100.0, 2.0, 1, 2, 0),
                (2, B0 + TF_MS, 101.0, 5.0, 3, 7, 1)]
        bars = self._bars(rows)
        self.assertEqual(len(bars), 2)
        self.assertAlmostEqual(bars[0].cvd_close, 2.0)
        self.assertAlmostEqual(bars[1].cvd_open, 2.0)
        self.assertAlmostEqual(bars[1].cvd_close, -3.0)


class TestCvdRebuildContinue(unittest.TestCase):
    """10: rebuild and continue must be bit-identical on the same dataset."""

    def setUp(self):
        self.t = TmpDB()
        rows = []
        aid = 1
        for i in range(240):                     # 5 days of 30m bars
            ts = B0 + i * TF_MS
            # deterministic pattern: alternating bursts
            for k in range(3):
                qty = 0.1 * ((i % 7) + 1)
                rows.append((aid, ts + k, 100.0 + (i % 11), qty, aid, aid,
                             (i + k) % 2))
                aid += 1
        seed(self.t.conn, rows)

    def tearDown(self):
        self.t.close()

    def test_rebuild_equals_continue(self):
        res = cvd.compare(self.t.conn, CFG.symbol, TF, split_ratio=0.6)
        self.assertTrue(res["equal"], msg=res.get("mismatches"))
        self.assertAlmostEqual(res["cvd_rebuild"], res["cvd_continue"])

    def test_rebuild_persists_and_continue_matches_cvd(self):
        r1 = cvd.rebuild(self.t.conn, CFG.symbol, TF)
        r2 = cvd.continue_(self.t.conn, CFG.symbol, TF)
        self.assertEqual(r1["status"], "ok")
        self.assertIn(r2["status"], ("ok", "up-to-date"))
        self.assertAlmostEqual(r1["cvd"], r2["cvd"])

    def test_stale_checkpoint_detected(self):
        cvd.rebuild(self.t.conn, CFG.symbol, TF)
        cp = db.load_checkpoint(self.t.conn, CFG.symbol, TF)
        self.t.conn.execute("DELETE FROM agg_trades WHERE agg_id=?",
                            (cp["last_agg_id"],))
        self.t.conn.commit()
        r = cvd.continue_(self.t.conn, CFG.symbol, TF)
        self.assertEqual(r["status"], "stale")


class TestGaps(unittest.TestCase):
    """6b: the three gap classes are computed independently."""

    def setUp(self):
        self.t = TmpDB()
        # day 1: ids 1..3, day 2: ids 10..12 (a hole 4..9)
        rows = [(1, B0 + 1, 100.0, 1, 1, 1, 0),
                (2, B0 + 2, 100.0, 1, 2, 2, 0),
                (3, B0 + 3, 100.0, 1, 3, 3, 0),
                (10, B0 + 86_400_000, 100.0, 1, 10, 10, 0),
                (11, B0 + 86_400_001, 100.0, 1, 11, 11, 0),
                (12, B0 + 86_400_002, 100.0, 1, 12, 12, 0)]
        seed(self.t.conn, rows)
        self.day1 = schema.utc_day(B0)
        self.day2 = schema.utc_day(B0 + 86_400_000)

    def tearDown(self):
        self.t.close()

    def test_id_gap_and_time_gap_reported_separately(self):
        c = gaps.continuity(self.t.conn, CFG.symbol, TF, silence_ms=60_000)
        self.assertEqual(c["id_gap_events"], 1)
        self.assertEqual(c["id_missing_total"], 6)
        self.assertEqual(c["empty_buckets"], 47)      # 48 buckets/day, 1 used
        self.assertGreater(c["max_silence_ms"], 60_000)

    def test_missing_file_is_not_no_trades(self):
        cov = gaps.archive_coverage(self.t.conn, CFG.symbol,
                                    self.day1 - __import__("datetime").timedelta(days=1),
                                    self.day2)
        statuses = dict((d["day"], d["status"]) for d in cov["days"])
        self.assertEqual(statuses[self.day1.isoformat()], "ok")
        self.assertEqual(statuses[self.day2.isoformat()], "ok")
        before = (self.day1 - __import__("datetime").timedelta(days=1)).isoformat()
        self.assertIn(statuses[before], ("missing_file", "not_loaded"))


class TestRaceFreeCatchup(unittest.TestCase):
    """11: WS/REST race. Simulated deterministically, not 'reviewed by eye'."""

    def setUp(self):
        self.t = TmpDB()
        seed(self.t.conn, [(i, B0 + i, 100.0, 1.0, i, i, 0) for i in range(1, 6)])

    def tearDown(self):
        self.t.close()

    def _row(self, i):
        return (i, B0 + i, 100.0, 1.0, i, i, 0)

    def test_no_record_lost_when_rest_lags_the_socket(self):
        """REST only reaches 7 while the socket already delivered 8..12."""
        buffered = [self._row(i) for i in range(8, 13)]

        def fetch(from_id, limit):
            if from_id > 7:
                return []
            return [self._row(i) for i in range(from_id, 8)]

        stats = stream.catch_up(self.t.conn, CFG.symbol, fetch, buffered)
        ids = [r[0] for r in self.t.conn.execute(
            "SELECT agg_id FROM agg_trades ORDER BY agg_id")]
        self.assertEqual(ids, list(range(1, 13)))
        self.assertTrue(stats["inserted"] >= 7)

    def test_hole_is_not_written_past(self):
        """Socket delivered 10..12 but REST only 6..7: 8,9 must NOT be skipped."""
        buffered = [self._row(i) for i in range(10, 13)]

        def fetch(from_id, limit):
            if from_id > 7:
                return []
            return [self._row(i) for i in range(from_id, 8)]

        stream.catch_up(self.t.conn, CFG.symbol, fetch, buffered)
        ids = [r[0] for r in self.t.conn.execute(
            "SELECT agg_id FROM agg_trades ORDER BY agg_id")]
        self.assertEqual(ids, list(range(1, 8)))     # 10..12 withheld

    def test_duplicate_overlap_does_not_double_count(self):
        buffered = [self._row(i) for i in range(3, 9)]

        def fetch(from_id, limit):
            return [self._row(i) for i in range(from_id, 10) if i <= 9]

        stream.catch_up(self.t.conn, CFG.symbol, fetch, buffered)
        ids = [r[0] for r in self.t.conn.execute(
            "SELECT agg_id FROM agg_trades ORDER BY agg_id")]
        self.assertEqual(ids, list(range(1, 10)))
        total = self.t.conn.execute("SELECT SUM(qty) s FROM agg_trades").fetchone()["s"]
        self.assertAlmostEqual(total, 9.0)

    def test_contiguous_prefix_stops_at_hole(self):
        tip = 5
        rows = [self._row(6), self._row(7), self._row(10), self._row(11)]
        got = stream.contiguous_prefix(rows, tip)
        self.assertEqual([r[0] for r in got], [6, 7])


class TestLiveEndpoints(unittest.TestCase):
    """12: real REST / WebSocket. Marked, never faked."""

    def test_rest_reachable(self):
        try:
            ok = sources.RestClient().ping()
        except sources.SourceUnavailable as e:
            self.skipTest("REST unavailable here: %s" % e)
        self.assertTrue(ok)


def main():
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(__import__("btcof.selftest", fromlist=["x"]))
    runner = unittest.TextTestRunner(verbosity=2)
    res = runner.run(suite)
    print("\nran=%d failures=%d errors=%d skipped=%d"
          % (res.testsRun, len(res.failures), len(res.errors), len(res.skipped)))
    return 0 if res.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
"""BTC M30 Adaptive Order Flow Strategy V1 - data engine (stage 1)."""
__version__ = "1.1.0"

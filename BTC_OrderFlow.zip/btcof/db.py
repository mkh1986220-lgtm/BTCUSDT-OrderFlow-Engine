"""SQLite storage.

Invariants
----------
1. `agg_trades` is the single source of truth; bars, CVD and gap reports are
   derived and rebuildable from it.
2. Primary key (symbol, agg_id) makes re-ingestion idempotent, which is what
   allows "resume from the last id" after a Colab disconnect.
3. Every batch is staged first, so we can count new rows, duplicates and
   CONFLICTING duplicates (same agg_id, different payload) separately. Silent
   overwrites are exactly what this project must not do.
4. `ingest_log` records, per source, how many rows were loaded and how many
   were duplicates/conflicts.
"""
from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from typing import Iterable, List, Optional

SCHEMA_VERSION = 11

DDL = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;

CREATE TABLE IF NOT EXISTS agg_trades (
    symbol         TEXT    NOT NULL,
    agg_id         INTEGER NOT NULL,
    ts             INTEGER NOT NULL,
    price          REAL    NOT NULL,
    qty            REAL    NOT NULL,
    first_tid      INTEGER NOT NULL,
    last_tid       INTEGER NOT NULL,
    is_buyer_maker INTEGER NOT NULL,
    PRIMARY KEY (symbol, agg_id)
) WITHOUT ROWID;

CREATE INDEX IF NOT EXISTS ix_agg_ts ON agg_trades(symbol, ts);

CREATE TABLE IF NOT EXISTS ingest_log (
    source     TEXT PRIMARY KEY,
    symbol     TEXT NOT NULL,
    kind       TEXT,               -- 'archive' | 'rest' | 'stream'
    first_id   INTEGER, last_id   INTEGER,
    ts_min     INTEGER, ts_max    INTEGER,
    rows       INTEGER, dupes     INTEGER, conflicts INTEGER,
    detail     TEXT,
    loaded_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS state (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS bars (
    symbol         TEXT    NOT NULL,
    tf_minutes     INTEGER NOT NULL,
    open_time      INTEGER NOT NULL,
    open REAL, high REAL, low REAL, close REAL,
    volume REAL, buy_vol REAL, sell_vol REAL,
    delta REAL, delta_pct REAL,
    agg_trades     INTEGER,          -- number of aggTrade records
    trades         INTEGER,          -- number of raw trades (sum last-first+1)
    vwap REAL, max_trade REAL, big_trades INTEGER,
    cvd_open REAL, cvd_close REAL,
    first_agg_id INTEGER, last_agg_id INTEGER, last_ts INTEGER,
    built_at TEXT DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (symbol, tf_minutes, open_time)
) WITHOUT ROWID;

CREATE TABLE IF NOT EXISTS cvd_checkpoints (
    symbol   TEXT NOT NULL,
    tf_minutes INTEGER NOT NULL,
    bar_open_time INTEGER NOT NULL,
    cvd_open REAL DEFAULT 0,
    cvd_value REAL NOT NULL,
    last_agg_id  INTEGER NOT NULL,
    last_ts      INTEGER NOT NULL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (symbol, tf_minutes)
);

CREATE TABLE IF NOT EXISTS errors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    at TEXT DEFAULT CURRENT_TIMESTAMP,
    kind TEXT, detail TEXT
);

CREATE TEMP TABLE IF NOT EXISTS stage (
    symbol TEXT, agg_id INTEGER, ts INTEGER, price REAL, qty REAL,
    first_tid INTEGER, last_tid INTEGER, is_buyer_maker INTEGER
);
"""


def connect(db_path: str) -> sqlite3.Connection:
    d = os.path.dirname(os.path.abspath(db_path))
    if d:
        os.makedirs(d, exist_ok=True)
    conn = sqlite3.connect(db_path, timeout=60.0)
    conn.row_factory = sqlite3.Row
    conn.executescript(DDL)
    conn.execute("PRAGMA user_version=%d" % SCHEMA_VERSION)
    return conn


@contextmanager
def session(db_path: str):
    conn = connect(db_path)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# state
# ---------------------------------------------------------------------------
def get_state(conn, key: str, default=None):
    row = conn.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_state(conn, key: str, value) -> None:
    conn.execute(
        "INSERT INTO state(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))


def log_error(conn, kind: str, detail: str) -> None:
    conn.execute("INSERT INTO errors(kind,detail) VALUES(?,?)", (kind, detail))


# ---------------------------------------------------------------------------
# agg_trades
# ---------------------------------------------------------------------------
def last_agg_id(conn, symbol: str) -> Optional[int]:
    r = conn.execute("SELECT MAX(agg_id) m FROM agg_trades WHERE symbol=?",
                     (symbol,)).fetchone()
    return r["m"]


def first_agg_id(conn, symbol: str) -> Optional[int]:
    r = conn.execute("SELECT MIN(agg_id) m FROM agg_trades WHERE symbol=?",
                     (symbol,)).fetchone()
    return r["m"]


def insert_rows(conn, symbol: str, rows: Iterable[Iterable]) -> dict:
    """Stage -> insert -> compare.

    Returns {'staged', 'inserted', 'dupes', 'conflicts'} where `conflicts` are
    rows whose agg_id already existed with a DIFFERENT payload (data integrity
    alarm, not a normal duplicate).
    """
    staged = 0
    conn.execute("DELETE FROM temp.stage")
    conn.executemany(
        "INSERT INTO temp.stage(symbol,agg_id,ts,price,qty,first_tid,last_tid,"
        "is_buyer_maker) VALUES(?,?,?,?,?,?,?,?)",
        ((symbol,) + tuple(r) for r in rows))
    staged = conn.execute("SELECT COUNT(*) c FROM temp.stage").fetchone()["c"]

    cur = conn.execute(
        "INSERT INTO agg_trades(symbol,agg_id,ts,price,qty,first_tid,last_tid,"
        "is_buyer_maker) SELECT symbol,agg_id,ts,price,qty,first_tid,last_tid,"
        "is_buyer_maker FROM temp.stage WHERE 1 "
        "ON CONFLICT(symbol,agg_id) DO NOTHING")
    inserted = cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0

    conflicts = conn.execute(
        "SELECT COUNT(*) c FROM temp.stage s JOIN agg_trades a "
        "ON a.symbol=s.symbol AND a.agg_id=s.agg_id "
        "WHERE a.ts<>s.ts OR a.price<>s.price OR a.qty<>s.qty "
        "  OR a.is_buyer_maker<>s.is_buyer_maker "
        "  OR a.first_tid<>s.first_tid OR a.last_tid<>s.last_tid").fetchone()["c"]

    conn.execute("DELETE FROM temp.stage")
    return {"staged": staged, "inserted": inserted,
            "dupes": staged - inserted, "conflicts": conflicts}


def log_ingest(conn, source: str, symbol: str, kind: str, first_id, last_id,
               ts_min, ts_max, rows, dupes, conflicts, detail="") -> None:
    conn.execute(
        "INSERT INTO ingest_log(source,symbol,kind,first_id,last_id,ts_min,"
        "ts_max,rows,dupes,conflicts,detail) VALUES(?,?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(source) DO UPDATE SET first_id=excluded.first_id,"
        "last_id=excluded.last_id,ts_min=excluded.ts_min,ts_max=excluded.ts_max,"
        "rows=excluded.rows,dupes=excluded.dupes,conflicts=excluded.conflicts,"
        "detail=excluded.detail,loaded_at=CURRENT_TIMESTAMP",
        (source, symbol, kind, first_id, last_id, ts_min, ts_max, rows, dupes,
         conflicts, detail))


def ingest_done(conn, source: str) -> bool:
    return conn.execute("SELECT 1 FROM ingest_log WHERE source=?",
                        (source,)).fetchone() is not None


# ---------------------------------------------------------------------------
# bars
# ---------------------------------------------------------------------------
BAR_COLS = ("symbol", "tf_minutes", "open_time", "open", "high", "low",
            "close", "volume", "buy_vol", "sell_vol", "delta", "delta_pct",
            "agg_trades", "trades", "vwap", "max_trade", "big_trades",
            "cvd_open", "cvd_close", "first_agg_id", "last_agg_id", "last_ts")


def upsert_bars(conn, rows: List[tuple]) -> int:
    if not rows:
        return 0
    sql = ("INSERT INTO bars(%s) VALUES(%s) ON CONFLICT(symbol,tf_minutes,"
           "open_time) DO UPDATE SET open=excluded.open,high=excluded.high,"
           "low=excluded.low,close=excluded.close,volume=excluded.volume,"
           "buy_vol=excluded.buy_vol,sell_vol=excluded.sell_vol,"
           "delta=excluded.delta,delta_pct=excluded.delta_pct,"
           "agg_trades=excluded.agg_trades,trades=excluded.trades,"
           "vwap=excluded.vwap,max_trade=excluded.max_trade,"
           "big_trades=excluded.big_trades,cvd_open=excluded.cvd_open,"
           "cvd_close=excluded.cvd_close,first_agg_id=excluded.first_agg_id,"
           "last_agg_id=excluded.last_agg_id,last_ts=excluded.last_ts,"
           "built_at=CURRENT_TIMESTAMP"
           % (",".join(BAR_COLS), ",".join("?" * len(BAR_COLS))))
    conn.executemany(sql, rows)
    return len(rows)


def fetch_bars(conn, symbol: str, tf: int, start_ms: int = 0,
               end_ms: int = 2 ** 62) -> List[sqlite3.Row]:
    return list(conn.execute(
        "SELECT * FROM bars WHERE symbol=? AND tf_minutes=? AND open_time>=? "
        "AND open_time<? ORDER BY open_time", (symbol, tf, start_ms, end_ms)))


# ---------------------------------------------------------------------------
# CVD checkpoints
# ---------------------------------------------------------------------------
def save_checkpoint(conn, symbol: str, tf: int, bar_open_time: int,
                    cvd_value: float, last_agg_id: int, last_ts: int,
                    cvd_open: float = 0.0) -> None:
    conn.execute(
        "INSERT INTO cvd_checkpoints(symbol,tf_minutes,bar_open_time,cvd_open,"
        "cvd_value,last_agg_id,last_ts) VALUES(?,?,?,?,?,?,?) "
        "ON CONFLICT(symbol,tf_minutes) DO UPDATE SET "
        "bar_open_time=excluded.bar_open_time,cvd_open=excluded.cvd_open,"
        "cvd_value=excluded.cvd_value,last_agg_id=excluded.last_agg_id,"
        "last_ts=excluded.last_ts,updated_at=CURRENT_TIMESTAMP",
        (symbol, tf, bar_open_time, cvd_open, cvd_value, last_agg_id, last_ts))


def load_checkpoint(conn, symbol: str, tf: int):
    r = conn.execute("SELECT * FROM cvd_checkpoints WHERE symbol=? AND "
                     "tf_minutes=?", (symbol, tf)).fetchone()
    return dict(r) if r else None
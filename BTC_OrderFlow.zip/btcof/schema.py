"""Column contracts + row validation for every AggTrades source.

VERIFIED AGAINST REAL FILES (2026-10-30 / 2026-10-31 archives):
    header present, 7 columns
    agg_trade_id,price,quantity,first_trade_id,last_trade_id,transact_time,is_buyer_maker
    3501055984,77962.7,0.071,8217262670,8217262670,1793318400050,false

Rules enforced here:
  * archive CSV is read BY HEADER NAME, never by bare position;
  * REST/WS JSON is read BY KEY, so payload field order is irrelevant;
  * timestamps are normalised to milliseconds once, at the boundary;
  * invalid rows raise instead of being written.

Canonical row tuple used everywhere downstream:
    (agg_id, ts_ms, price, qty, first_tid, last_tid, is_buyer_maker)
"""
from __future__ import annotations

import datetime as _dt
import math
import re
from typing import Dict, Optional, Sequence, Tuple

AGG_COLUMNS = (
    "agg_trade_id", "price", "quantity", "first_trade_id",
    "last_trade_id", "transact_time", "is_buyer_maker",
)

# REST /fapi/v1/aggTrades and WS <symbol>@aggTrade payload keys
REST_KEYS = {
    "agg_id": "a", "price": "p", "qty": "q", "first_tid": "f",
    "last_tid": "l", "ts": "T", "is_buyer_maker": "m",
}

Row = Tuple[int, int, float, float, int, int, int]

_DAY_RE = re.compile(r"(\d{4}-\d{2}-\d{2})")

# ---------------------------------------------------------------------------
# timestamp unit handling
# ---------------------------------------------------------------------------
# 2026 epoch seconds ~ 1.79e9
#   seconds     -> 1.79e9   (10 digits)
#   milliseconds-> 1.79e12  (13 digits)
#   microseconds-> 1.79e15  (16 digits)
#   nanoseconds -> 1.79e18  (19 digits)
_MS_MAX = 10 ** 14          # anything above this cannot be milliseconds today
_NS_MIN = 10 ** 17


def detect_ts_unit(value: int) -> str:
    """Classify a raw timestamp. Raises if it cannot be a real epoch."""
    v = int(value)
    if v <= 0:
        raise ValueError("timestamp is not positive: %r" % (v,))
    if v < 10 ** 11:
        return "s"
    if v < _MS_MAX:
        return "ms"
    if v < _NS_MIN:
        return "us"
    return "ns"


_UNIT_DIV = {"s": 1, "ms": 1, "us": 1000, "ns": 1_000_000}


def to_ms(value: int, unit: str) -> int:
    """Normalise a timestamp of a known unit to milliseconds."""
    if unit not in _UNIT_DIV:
        raise ValueError("unknown timestamp unit %r" % (unit,))
    v = int(value)
    if unit == "s":
        return v * 1000
    return v // _UNIT_DIV[unit]


class SchemaError(ValueError):
    """Raised when a source does not match its declared contract."""


# ---------------------------------------------------------------------------
# archive CSV
# ---------------------------------------------------------------------------
def bool_from_text(s: str) -> int:
    v = str(s).strip().lower()
    if v in ("true", "1"):
        return 1
    if v in ("false", "0"):
        return 0
    raise SchemaError("is_buyer_maker is not a boolean: %r" % (s,))


def looks_like_header(fields: Sequence[str]) -> bool:
    return bool(fields) and not str(fields[0]).strip().lstrip("-").isdigit()


def header_index(header: Sequence[str]) -> Dict[str, int]:
    """Build name->index from the file's own header line.

    The contract is on the SET of names, not on their order: a file that
    re-orders its columns must still load correctly (that is the whole point of
    mapping by name). Missing, duplicate or unknown names are rejected.
    """
    names = [h.strip().lower() for h in header]
    if len(names) != len(AGG_COLUMNS):
        raise SchemaError(
            "archive header has %d columns, expected %d: %r"
            % (len(names), len(AGG_COLUMNS), names))
    if len(set(names)) != len(names):
        raise SchemaError("archive header has duplicate column names: %r"
                          % (names,))
    unknown = [n for n in names if n not in AGG_COLUMNS]
    missing = [n for n in AGG_COLUMNS if n not in names]
    if unknown or missing:
        raise SchemaError(
            "archive header does not match the contract.\n"
            "  unknown: %r\n  missing: %r" % (unknown, missing))
    return {n: i for i, n in enumerate(names)}


def row_from_fields(fields: Sequence[str], idx: Dict[str, int],
                    unit: str) -> Row:
    """Archive CSV row -> canonical tuple using the header map."""
    return (
        int(fields[idx["agg_trade_id"]]),
        to_ms(int(fields[idx["transact_time"]]), unit),
        float(fields[idx["price"]]),
        float(fields[idx["quantity"]]),
        int(fields[idx["first_trade_id"]]),
        int(fields[idx["last_trade_id"]]),
        bool_from_text(fields[idx["is_buyer_maker"]]),
    )


class RowValidator:
    """Hard checks raise (the file is not what we think it is).
    Soft checks count anomalies and are always reported, never hidden."""

    def __init__(self, day_ms: Optional[int] = None,
                 window_ms: int = 2 * 3600 * 1000):
        self.day_ms = day_ms
        self.window_ms = window_ms
        self.prev_ts = None
        self.prev_price = None
        self.prev_agg_id = None
        self.prev_last_tid = None
        self.stats = {
            "rows": 0, "ts_backwards": 0, "agg_id_gaps": 0,
            "trade_id_gaps": 0, "missing_trade_ids": 0,
            "price_jumps": 0, "out_of_window": 0,
        }

    def check(self, r: Row) -> Row:
        agg_id, ts, price, qty, ftid, ltid, ibm = r
        if price <= 0 or not math.isfinite(price):
            raise SchemaError("price is not a positive finite number: %r" % (price,))
        if qty <= 0 or not math.isfinite(qty):
            raise SchemaError("qty is not a positive finite number: %r" % (qty,))
        if ts <= 0:
            raise SchemaError("timestamp is not a positive epoch: %r" % (ts,))
        if ftid > ltid:
            raise SchemaError("first_trade_id > last_trade_id: %r" % (r,))
        if ibm not in (0, 1):
            raise SchemaError("is_buyer_maker not 0/1: %r" % (ibm,))

        if self.day_ms is not None:
            lo = self.day_ms - self.window_ms
            hi = self.day_ms + 86_400_000 + self.window_ms
            if not (lo <= ts <= hi):
                self.stats["out_of_window"] += 1
                raise SchemaError(
                    "trade timestamp %d is outside the file's day window "
                    "[%d, %d]: transact_time is probably not where we think "
                    "it is (or the unit is wrong)" % (ts, lo, hi))

        if self.prev_price is not None:
            if price > self.prev_price * 1.5 or price < self.prev_price * 0.5:
                self.stats["price_jumps"] += 1
                if self.stats["price_jumps"] > 3:
                    raise SchemaError(
                        "price jumped %.2f -> %.2f; column order is suspect"
                        % (self.prev_price, price))
        if self.prev_ts is not None and ts < self.prev_ts:
            self.stats["ts_backwards"] += 1
        if self.prev_agg_id is not None and agg_id != self.prev_agg_id + 1:
            self.stats["agg_id_gaps"] += 1
        if self.prev_last_tid is not None and ftid != self.prev_last_tid + 1:
            if ftid > self.prev_last_tid + 1:
                self.stats["missing_trade_ids"] += ftid - self.prev_last_tid - 1
            self.stats["trade_id_gaps"] += 1

        self.prev_ts, self.prev_price = ts, price
        self.prev_agg_id, self.prev_last_tid = agg_id, ltid
        self.stats["rows"] += 1
        return r


# ---------------------------------------------------------------------------
# REST / WebSocket JSON
# ---------------------------------------------------------------------------
def row_from_rest(obj: dict, require_trade_ids: bool = False) -> Row:
    """JSON aggTrade -> canonical tuple. Keyed access only.

    Binance sends price/quantity as strings and ids/timestamps as ints; both
    forms are accepted so a format drift cannot corrupt the data.
    """
    missing = [k for k in ("a", "p", "q", "T", "m") if k not in obj]
    if missing:
        raise SchemaError("payload missing keys %r (present: %r)"
                          % (missing, sorted(obj.keys())))
    ftid, ltid = obj.get("f"), obj.get("l")
    if require_trade_ids and (ftid is None or ltid is None):
        raise SchemaError("payload missing f/l: %r" % (sorted(obj.keys()),))

    raw_ts = int(obj["T"])
    unit = detect_ts_unit(raw_ts)
    ts = to_ms(raw_ts, unit)

    agg_id = int(obj["a"])
    return (
        agg_id, ts, float(obj["p"]), float(obj["q"]),
        int(ftid) if ftid is not None else agg_id,
        int(ltid) if ltid is not None else agg_id,
        1 if bool(obj["m"]) else 0,
    )


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def day_ms_from_filename(path: str) -> Optional[int]:
    name = path.replace("\\", "/").split("/")[-1]
    m = _DAY_RE.search(name)
    if not m:
        return None
    d = _dt.datetime.strptime(m.group(1), "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc)
    return int(d.timestamp() * 1000)


def day_ms(d) -> int:
    return int(_dt.datetime(d.year, d.month, d.day,
                            tzinfo=_dt.timezone.utc).timestamp() * 1000)


def utc_day(ms: int):
    return _dt.datetime.fromtimestamp(ms / 1000, tz=_dt.timezone.utc).date()
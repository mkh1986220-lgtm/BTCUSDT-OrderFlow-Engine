"""Configuration. OS-agnostic so the same file runs on Colab, a Linux VPS and
a Windows shell (paths are always built with os.path, never with '/').

Stage 1 scope: data acquisition, storage, validation, order flow.
No strategy / no risk model / no backtest yet.
"""
from __future__ import annotations

import os
from dataclasses import dataclass


def _root() -> str:
    return os.environ.get("BTCOF_ROOT") or os.getcwd()


@dataclass(frozen=True)
class Config:
    # instrument
    symbol: str = "BTCUSDT"
    market: str = "um"                 # USD-M futures
    tf_minutes: int = 30               # entry timeframe M30
    htf_minutes: int = 240             # trend filter timeframe H4 (built, not used yet)

    # endpoints
    rest_base: str = "https://fapi.binance.com"
    archive_base: str = "https://data.binance.vision"
    ws_base: str = "wss://fstream.binance.com/ws"

    # storage
    root: str = ""
    db_path: str = "data/btcof.db"
    raw_dir: str = "data/raw"
    log_dir: str = "logs"

    # batching (kept modest for 32-bit / low-RAM hosts)
    batch_rows: int = 100_000
    bar_chunk_days: int = 2

    # order-flow parameters
    big_qty: float = 3.0
    divergence_lookback: int = 24
    pivot_left: int = 3
    pivot_right: int = 3
    absorption_z: float = 1.5

    # gap reporting
    intertrade_gap_ms: int = 60_000    # "unusual" silence threshold

    # network
    http_timeout: int = 30
    retry_max: int = 5

    def __post_init__(self):
        if not self.root:
            object.__setattr__(self, "root", _root())

    def path(self, rel: str) -> str:
        if os.path.isabs(rel):
            return rel
        return os.path.join(self.root, *rel.split("/"))

    def ensure_dirs(self) -> None:
        for rel in (self.raw_dir, self.log_dir,
                    os.path.dirname(self.db_path) or "."):
            os.makedirs(self.path(rel), exist_ok=True)


CFG = Config()
"""High level ingestion: archive ZIP -> SQLite, with resume semantics.

Guarantees
----------
* A day already in `ingest_log` is skipped, so an interrupted Colab session
  resumes instead of re-downloading.
* Re-reading the same file is harmless: rows are deduplicated on agg_id and
  *conflicting* duplicates are counted separately and logged.
* A missing archive file is recorded as `missing` — it is NOT interpreted as
  "no trades on that day".
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Optional

from . import db, schema, sources
from .config import CFG


def ingest_archive_day(conn, symbol: str, d: date, force: bool = False,
                       keep_file: bool = True) -> dict:
    tag = "archive:%s:%s" % (symbol, d.isoformat())
    if not force and db.ingest_done(conn, tag):
        return {"source": tag, "status": "skip"}

    url = sources.daily_url(symbol, d)
    dest = CFG.path("%s/%s-aggTrades-%s.zip" % (CFG.raw_dir, symbol,
                                                d.isoformat()))
    try:
        path = sources.fetch_to_disk(url, dest)
    except sources.SourceUnavailable as e:
        db.log_error(conn, "source_unavailable", str(e))
        return {"source": tag, "status": "blocked", "detail": str(e)}
    if path is None:
        db.log_ingest(conn, tag, symbol, "archive", None, None, None, None,
                      0, 0, 0, "file not published")
        return {"source": tag, "status": "missing"}

    totals = {"staged": 0, "inserted": 0, "dupes": 0, "conflicts": 0}
    first_id = last_id = ts_min = ts_max = None
    batch = []
    status = "ok"
    reader = sources.AggArchiveFile(path)

    try:
        for row in reader:
            batch.append(row)
            if len(batch) >= CFG.batch_rows:
                r = db.insert_rows(conn, symbol, batch)
                for k in totals:
                    totals[k] += r[k]
                batch = []
                conn.commit()
        if batch:
            r = db.insert_rows(conn, symbol, batch)
            for k in totals:
                totals[k] += r[k]
            conn.commit()
    except schema.SchemaError as e:
        conn.commit()
        status = "schema_error"
        db.log_error(conn, "schema_error", "%s: %s" % (tag, e))
        db.log_ingest(conn, tag, symbol, "archive", None, None, None, None,
                      0, 0, 0, "SCHEMA ERROR: %s" % e)
        return {"source": tag, "status": status, "detail": str(e)}

    row = conn.execute(
        "SELECT MIN(agg_id) a, MAX(agg_id) b, MIN(ts) t0, MAX(ts) t1 "
        "FROM agg_trades WHERE symbol=?", (symbol,)).fetchone()
    first_id, last_id, ts_min, ts_max = row["a"], row["b"], row["t0"], row["t1"]

    db.log_ingest(conn, tag, symbol, "archive", first_id, last_id, ts_min,
                  ts_max, totals["inserted"], totals["dupes"],
                  totals["conflicts"], "unit=%s" % reader.unit)
    conn.commit()

    if not keep_file:
        try:
            import os
            os.remove(path)
        except OSError:
            pass

    return {"source": tag, "status": status, "rows": totals["inserted"],
            "dupes": totals["dupes"], "conflicts": totals["conflicts"],
            "unit": reader.unit, "reader_stats": reader.stats()}


def ingest_range(conn, symbol: str, start: date, end: date,
                 force: bool = False) -> list:
    out = []
    d = start
    while d <= end:
        res = ingest_archive_day(conn, symbol, d, force=force)
        print("  %s -> %-7s rows=%-8s dupes=%-4s unit=%s"
              % (d, res["status"], res.get("rows", "-"), res.get("dupes", "-"),
                 res.get("unit", "-")))
        out.append(res)
        d += timedelta(days=1)
    return out


def catch_up(conn, symbol: str, until_ms: Optional[int] = None,
             max_calls: int = 500) -> dict:
    """Fill the tail after the last stored aggTrade using REST.

    If REST is blocked this returns {'status': 'blocked'} — it never pretends
    the gap was filled.
    """
    last = db.last_agg_id(conn, symbol)
    if last is None:
        return {"status": "empty", "detail": "no rows yet; use the archive first"}
    until_ms = until_ms or sources.utcnow_ms()
    api = sources.RestClient()
    cursor = last + 1
    totals = {"staged": 0, "inserted": 0, "dupes": 0, "conflicts": 0}
    try:
        for _ in range(max_calls):
            rows = api.agg_trades(symbol, from_id=cursor)
            if not rows:
                break
            fresh = [r for r in rows if r[0] > last]
            if fresh:
                r = db.insert_rows(conn, symbol, fresh)
                for k in totals:
                    totals[k] += r[k]
                conn.commit()
            cursor = rows[-1][0] + 1
            if len(rows) < 1000 or rows[-1][1] >= until_ms:
                break
    except sources.SourceUnavailable as e:
        db.log_error(conn, "source_unavailable", str(e))
        conn.commit()
        return {"status": "blocked", "detail": str(e), "inserted": totals["inserted"]}

    if totals["inserted"]:
        db.log_ingest(conn, "rest:%s:%d" % (symbol, last + 1), symbol, "rest",
                      last + 1, db.last_agg_id(conn, symbol), None, None,
                      totals["inserted"], totals["dupes"], totals["conflicts"])
        conn.commit()
    return {"status": "ok", "inserted": totals["inserted"],
            "dupes": totals["dupes"], "last_agg_id": db.last_agg_id(conn, symbol)}


def missing_days(conn, symbol: str, start: date, end: date) -> list:
    """Days in the window with no successful archive load recorded."""
    out = []
    d = start
    while d <= end:
        tag = "archive:%s:%s" % (symbol, d.isoformat())
        row = conn.execute("SELECT detail FROM ingest_log WHERE source=?",
                           (tag,)).fetchone()
        if row is None or (row["detail"] or "").startswith("file not published"):
            out.append(d.isoformat())
        d += timedelta(days=1)
    return out
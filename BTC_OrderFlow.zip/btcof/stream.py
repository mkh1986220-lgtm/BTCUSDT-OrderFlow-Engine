"""Live AggTrades collection without losing prints.

The race
--------
If you read the last id from the DB and *then* subscribe, every print that
happens between the two is invisible: REST does not return it (it did not exist
when REST was asked) and the socket never delivered it (it was not subscribed).
If you subscribe first and backfill second, the overlap is duplicated instead —
which is harmless, because agg_id is a primary key.

Implementation
--------------
1. Subscribe FIRST, buffer frames in memory.
2. Backfill from `last_agg_id + 1` by REST.
3. Merge only the buffered rows that are CONTIGUOUS with the current DB tip
   (`contiguous_prefix`). Rows beyond a hole are never written, so the DB can
   never contain a silent gap.
4. Repeat until REST returns nothing new and no buffered row is pending.
5. Switch to steady streaming, flushing in batches.

Python 3.8 safe: no asyncio.to_thread (3.9+); an executor is used instead.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from typing import Callable, Dict, List, Optional

from . import db, schema
from .config import CFG

log = logging.getLogger("btcof.stream")


# ---------------------------------------------------------------------------
# message parsing
# ---------------------------------------------------------------------------
def parse_ws_message(raw: str) -> Optional[schema.Row]:
    """Return a canonical row, or raise SchemaError / ValueError.

    Handles: non-JSON, json that is not an aggTrade, missing keys, string
    numbers. Callers count and log the failures, never crash the stream.
    """
    obj = json.loads(raw)
    if not isinstance(obj, dict):
        raise schema.SchemaError("payload is not an object")
    ev = obj.get("e")
    if ev is not None and ev != "aggTrade":
        return None
    return schema.row_from_rest(obj)


# ---------------------------------------------------------------------------
# reconciliation (pure, testable)
# ---------------------------------------------------------------------------
def contiguous_prefix(rows: List[schema.Row], tip: Optional[int]) -> List[schema.Row]:
    """Longest run of rows that can be appended to the DB without creating a
    hole. Rows at or below the tip are duplicates; the first gap stops it."""
    rows = sorted(rows, key=lambda r: r[0])
    if not rows:
        return []
    out = []
    expect = (tip + 1) if tip is not None else rows[0][0]
    for r in rows:
        if r[0] < expect:
            continue                    # duplicate, skip
        if r[0] != expect:
            break                       # hole -> stop, do not write past it
        out.append(r)
        expect += 1
    return out


def catch_up(conn, symbol: str, fetch_fn: Callable[[int, int], List[schema.Row]],
             buffered: List[schema.Row], max_rounds: int = 20,
             page: int = 1000) -> Dict:
    """Bring the DB up to date without leaving a hole.

    fetch_fn(from_id, limit) -> list of rows (may be empty when the endpoint is
    unavailable; that is reported, not hidden).
    """
    stats = {"rounds": 0, "inserted": 0, "from_buffer": 0,
             "unresolved_gap": False, "fetch_empty_rounds": 0}
    for _ in range(max_rounds):
        stats["rounds"] += 1
        progressed = False

        # --- 1) REST backfill from the current tip ---------------------------
        l = db.last_agg_id(conn, symbol)
        cursor = 0 if l is None else l + 1
        new_from_rest = 0
        for _page in range(200):
            rows = fetch_fn(cursor, page)
            if not rows:
                stats["fetch_empty_rounds"] += 1
                break
            rows = sorted(rows, key=lambda r: r[0])
            if l is not None:
                rows = [r for r in rows if r[0] > l]
            if not rows:
                break
            res = db.insert_rows(conn, symbol, rows)
            new_from_rest += res["inserted"]
            cursor = rows[-1][0] + 1
            if len(rows) < page:
                break
        conn.commit()
        if new_from_rest:
            stats["inserted"] += new_from_rest
            progressed = True

        # --- 2) merge the contiguous part of the buffered stream -------------
        tip = db.last_agg_id(conn, symbol)
        ready = contiguous_prefix(buffered, tip)
        if ready:
            res = db.insert_rows(conn, symbol, ready)
            stats["inserted"] += res["inserted"]
            stats["from_buffer"] += res["inserted"]
            progressed = True
            conn.commit()

        # --- 3) anything left pending behind a hole? -------------------------
        tip = db.last_agg_id(conn, symbol)
        pending = [r for r in buffered if r[0] > (tip or 0)]
        if not pending:
            stats["unresolved_gap"] = False
            break
        if not progressed:
            stats["unresolved_gap"] = True
            db.log_error(conn, "gap_unresolved",
                         "no progress with %d buffered rows pending at %s"
                         % (len(pending), symbol))
            conn.commit()
            break
    return stats


# ---------------------------------------------------------------------------
# live collector
# ---------------------------------------------------------------------------
class Collector(object):
    def __init__(self, db_path: str, symbol: str = CFG.symbol,
                 ws_url: Optional[str] = None, rest_client=None,
                 flush_every: int = 500, flush_seconds: float = 2.0):
        self.db_path = db_path
        self.symbol = symbol
        self.ws_url = ws_url or "%s/%s@aggTrade" % (CFG.ws_base, symbol.lower())
        self.rest = rest_client
        self.flush_every = flush_every
        self.flush_seconds = flush_seconds
        self.buffer = []
        self.stats = {"received": 0, "stored": 0, "invalid": 0,
                      "reconnects": 0, "dupes": 0, "backfilled": 0}

    # -- db helpers -------------------------------------------------------
    def _write(self, rows: List[schema.Row]) -> None:
        with db.session(self.db_path) as conn:
            res = db.insert_rows(conn, self.symbol, rows)
            self.stats["stored"] += res["inserted"]
            self.stats["dupes"] += res["dupes"]
            db.set_state(conn, "%s:last_live_id" % self.symbol, rows[-1][0])

    def _backfill(self) -> Dict:
        if self.rest is None:
            return {"status": "no-rest-client"}
        with db.session(self.db_path) as conn:
            res = catch_up(conn, self.symbol,
                           lambda fid, lim: self.rest.agg_trades(
                               self.symbol, from_id=fid, limit=lim),
                           list(self.buffer))
            db.set_state(conn, "%s:last_catchup" % self.symbol,
                         time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
            return res

    # -- main loop --------------------------------------------------------
    async def run(self, seconds: Optional[int] = None) -> Dict:
        import aiohttp

        loop = asyncio.get_event_loop()
        t_end = None if seconds is None else time.time() + seconds
        backoff = 1

        while t_end is None or time.time() < t_end:
            try:
                async with aiohttp.ClientSession() as sess:
                    async with sess.ws_connect(self.ws_url, heartbeat=20) as ws:
                        log.info("connected %s", self.ws_url)
                        self.stats["reconnects"] += 0 if backoff == 1 else 1
                        backoff = 1
                        # 1) REST catch-up with the socket already buffering
                        res = await loop.run_in_executor(None, self._backfill)
                        self.stats["backfilled"] += res.get("inserted", 0)
                        log.info("catch-up: %s", res)

                        last_flush = time.time()
                        async for msg in ws:
                            if msg.type != aiohttp.WSMsgType.TEXT:
                                if msg.type in (aiohttp.WSMsgType.CLOSED,
                                                aiohttp.WSMsgType.ERROR):
                                    break
                                continue
                            try:
                                row = parse_ws_message(msg.data)
                            except Exception as e:            # invalid payload
                                self.stats["invalid"] += 1
                                log.warning("invalid message: %r", e)
                                continue
                            if row is None:
                                continue
                            self.stats["received"] += 1
                            self.buffer.append(row)
                            if (len(self.buffer) >= self.flush_every
                                    or time.time() - last_flush > self.flush_seconds):
                                await loop.run_in_executor(
                                    None, self._write, list(self.buffer))
                                self.buffer = []
                                last_flush = time.time()
                            if t_end and time.time() >= t_end:
                                break
                        if self.buffer:
                            await loop.run_in_executor(
                                None, self._write, list(self.buffer))
                            self.buffer = []
                        if t_end and time.time() >= t_end:
                            return self.stats
            except Exception as e:                            # noqa: BLE001
                self.stats["reconnects"] += 1
                log.warning("socket error %r; retry in %ss", e, backoff)
                with db.session(self.db_path) as conn:
                    db.log_error(conn, "ws_error", repr(e))
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
        return self.stats


def setup_logging(db_path: str) -> None:
    CFG.ensure_dirs()
    path = os.path.join(CFG.path(CFG.log_dir), "btcof.log")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        handlers=[logging.FileHandler(path, encoding="utf-8"),
                  logging.StreamHandler()])


def run_live(db_path: str, seconds: Optional[int] = 3600,
             rest_client=None) -> Dict:
    setup_logging(db_path)
    return asyncio.get_event_loop().run_until_complete(
        Collector(db_path, rest_client=rest_client).run(seconds))
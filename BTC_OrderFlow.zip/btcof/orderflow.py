"""Order Flow Engine: AggTrades -> M30 bars.

Contract (write it down, everything downstream depends on it):
    is_buyer_maker == 0  ->  the taker was the BUYER   -> buy volume
    is_buyer_maker == 1  ->  the taker was the SELLER  -> sell volume
    delta      = buy_vol - sell_vol                     (BTC)
    delta_pct  = delta / (buy_vol + sell_vol) * 100     (%)
    cvd        = running sum of delta, anchored at cvd_base
    trades     = number of raw trades = sum(last_tid - first_tid + 1)
    agg_trades = number of aggTrade records (a different number, on purpose)

No candle-derived delta is used anywhere.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterator, List, Optional

from . import db


@dataclass
class Bar:
    open_time: int
    open: float = 0.0
    high: float = -math.inf
    low: float = math.inf
    close: float = 0.0
    volume: float = 0.0
    buy_vol: float = 0.0
    sell_vol: float = 0.0
    agg_trades: int = 0
    trades: int = 0
    pv: float = 0.0
    max_trade: float = 0.0
    big_trades: int = 0
    cvd_open: float = 0.0
    cvd_close: float = 0.0
    first_agg_id: Optional[int] = None
    last_agg_id: Optional[int] = None
    last_ts: Optional[int] = None
    # derived
    delta: float = 0.0
    delta_pct: float = 0.0
    vwap: float = 0.0
    close_pos: float = 0.0
    body_frac: float = 0.0
    z_volume: float = 0.0
    cvd_slope: float = 0.0
    divergence: Optional[dict] = None
    absorption: Optional[dict] = None

    def to_row(self, symbol: str, tf: int) -> tuple:
        return (symbol, tf, self.open_time, self.open, self.high, self.low,
                self.close, self.volume, self.buy_vol, self.sell_vol,
                self.delta, self.delta_pct, self.agg_trades, self.trades,
                self.vwap, self.max_trade, self.big_trades, self.cvd_open,
                self.cvd_close, self.first_agg_id, self.last_agg_id,
                self.last_ts)


def iter_bars(conn, symbol: str, tf_minutes: int,
              start_ms: Optional[int] = None, end_ms: Optional[int] = None,
              cvd_base: float = 0.0, big_qty: float = 3.0) -> Iterator[Bar]:
    """Stream aggTrades (ordered by ts) and emit closed bars."""
    tf_ms = tf_minutes * 60_000
    sql = ("SELECT agg_id, ts, price, qty, first_tid, last_tid, "
           "is_buyer_maker FROM agg_trades WHERE symbol=?")
    args = [symbol]
    if start_ms is not None:
        sql += " AND ts>=?"
        args.append(start_ms)
    if end_ms is not None:
        sql += " AND ts<?"
        args.append(end_ms)
    sql += " ORDER BY ts, agg_id"

    cvd = cvd_base
    cur = None
    for agg_id, ts, price, qty, ftid, ltid, ibm in conn.execute(sql, args):
        bucket = ts - (ts % tf_ms)
        if cur is not None and bucket != cur.open_time:
            cur.cvd_close = cvd
            yield cur
            cur = None
        if cur is None:
            cur = Bar(open_time=bucket, open=price, cvd_open=cvd,
                      first_agg_id=agg_id)
        b = cur
        if price > b.high:
            b.high = price
        if price < b.low:
            b.low = price
        b.close = price
        b.volume += qty
        b.pv += price * qty
        b.agg_trades += 1
        b.trades += max(0, ltid - ftid + 1)
        if qty > b.max_trade:
            b.max_trade = qty
        if qty >= big_qty:
            b.big_trades += 1
        b.last_agg_id = agg_id
        b.last_ts = ts
        if ibm:
            b.sell_vol += qty
            cvd -= qty
        else:
            b.buy_vol += qty
            cvd += qty
    if cur is not None:
        cur.cvd_close = cvd
        yield cur


def finalize(b: Bar) -> None:
    if b.high == -math.inf:
        b.high = b.low = b.close = b.open
    b.delta = b.buy_vol - b.sell_vol
    tot = b.buy_vol + b.sell_vol
    b.delta_pct = (b.delta / tot * 100.0) if tot > 0 else 0.0
    b.vwap = (b.pv / b.volume) if b.volume > 0 else b.close
    rng = b.high - b.low
    b.close_pos = ((b.close - b.low) / rng) if rng > 0 else 0.5
    b.body_frac = (abs(b.close - b.open) / rng) if rng > 0 else 0.0
    b.cvd_slope = b.cvd_close - b.cvd_open


def _rolling_z(values: List[float], window: int = 50) -> List[float]:
    out, hist = [], []
    for v in values:
        if len(hist) >= 10:
            m = sum(hist) / len(hist)
            sd = math.sqrt(sum((x - m) ** 2 for x in hist) / len(hist))
            if sd > 0:
                out.append((v - m) / sd)
            else:
                out.append(0.0 if abs(v - m) < 1e-12 else 5.0)
        else:
            out.append(0.0)
        hist.append(v)
        if len(hist) > window:
            hist.pop(0)
    return out


def find_pivots(vals: List[float], left: int = 3, right: int = 3,
                kind: str = "high") -> List[int]:
    """Confirmed swings only: a pivot needs `right` later bars, which is why
    signals are stamped at pivot+right and the pipeline stays look-ahead free."""
    idx = []
    n = len(vals)
    for i in range(left, n - right):
        w = vals[i - left:i + right + 1]
        if kind == "high" and vals[i] == max(w) and w.count(vals[i]) == 1:
            idx.append(i)
        elif kind == "low" and vals[i] == min(w) and w.count(vals[i]) == 1:
            idx.append(i)
    return idx


def detect_divergence(bars: List[Bar], lookback: int = 24,
                      left: int = 3, right: int = 3) -> List[dict]:
    n = len(bars)
    out = []
    lo = max(0, n - lookback - right)
    seg = bars[lo:]
    px = [b.close for b in seg]
    cvd = [b.cvd_close for b in seg]
    for kind, ck in (("bearish", "high"), ("bullish", "low")):
        piv = find_pivots(px, left, right, ck)
        if len(piv) < 2:
            continue
        p1, p2 = piv[-2], piv[-1]
        if kind == "bearish":
            px_moved, cvd_moved = px[p2] - px[p1], cvd[p2] - cvd[p1]
        else:
            px_moved, cvd_moved = px[p1] - px[p2], cvd[p1] - cvd[p2]
        if px_moved <= 0 or cvd_moved >= 0:
            continue
        emit_at = lo + p2 + right
        if emit_at >= n:
            continue
        out.append({
            "bar_index": emit_at, "pivot_index": lo + p2, "type": kind,
            "price_gap_pct": round(px_moved / px[p1] * 100, 4),
            "cvd_gap": round(cvd_moved, 3),
            "strength": round(min(1.0, abs(cvd_moved) /
                                  (abs(cvd[p2] - cvd[0]) + 1e-9)), 3)})
    return out


def detect_absorption(b: Bar, z_thr: float = 1.5) -> Optional[dict]:
    if abs(b.z_volume) < z_thr:
        return None
    vol_s = min(1.0, abs(b.z_volume) / (2 * z_thr))
    dlt_s = min(1.0, abs(b.delta_pct) / 40.0)
    if b.delta_pct <= -10 and b.close_pos >= 0.55:
        score = 0.5 * vol_s + 0.3 * dlt_s + 0.2 * (b.close_pos - 0.5) / 0.5
        return {"type": "bid", "score": round(min(1.0, score), 3),
                "reason": "sell delta absorbed, close in upper range"}
    if b.delta_pct >= 10 and b.close_pos <= 0.45:
        score = 0.5 * vol_s + 0.3 * dlt_s + 0.2 * (0.5 - b.close_pos) / 0.5
        return {"type": "ask", "score": round(min(1.0, score), 3),
                "reason": "buy delta absorbed, close in lower range"}
    return None


def annotate(bars: List[Bar], z_thr: float = 1.5, lookback: int = 24) -> None:
    for b, z in zip(bars, _rolling_z([b.volume for b in bars])):
        b.z_volume = round(z, 3)
        b.absorption = detect_absorption(b, z_thr)
    for d in detect_divergence(bars, lookback=lookback):
        i = d["bar_index"]
        prev = bars[i].divergence
        if prev is None or d["strength"] > prev.get("strength", 0):
            bars[i].divergence = d


def build_bars(conn, symbol: str, tf_minutes: int = 30,
               start_ms: Optional[int] = None, end_ms: Optional[int] = None,
               big_qty: float = 3.0, with_annotations: bool = True,
               cvd_base: float = 0.0) -> List[Bar]:
    bars = []
    for b in iter_bars(conn, symbol, tf_minutes, start_ms, end_ms,
                       cvd_base=cvd_base, big_qty=big_qty):
        finalize(b)
        bars.append(b)
    if with_annotations:
        annotate(bars)
    return bars


def persist_bars(conn, symbol: str, tf_minutes: int, bars: List[Bar]) -> int:
    rows = [b.to_row(symbol, tf_minutes) for b in bars]
    n = db.upsert_bars(conn, rows)
    conn.commit()
    return n


def big_qty_profile(conn, symbol: str) -> dict:
    """Empirical print-size quantiles, so `big_qty` is calibrated from data."""
    out = {}
    for p in ("0.5", "0.9", "0.99", "0.999"):
        row = conn.execute(
            "SELECT qty FROM agg_trades WHERE symbol=? ORDER BY qty LIMIT 1 "
            "OFFSET (SELECT CAST(COUNT(*)*%s AS INTEGER) FROM agg_trades "
            "WHERE symbol=?)" % p, (symbol, symbol)).fetchone()
        out[p] = row["qty"] if row else None
    return out
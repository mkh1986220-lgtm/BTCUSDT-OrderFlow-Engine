"""Acquisition: archive ZIPs, REST, WebSocket payloads.

Every source is parsed through `schema`, so a format change fails loudly.
The archive parser detects the timestamp unit from the data itself and
normalises to milliseconds before anything is stored.
"""
from __future__ import annotations

import csv
import io
import os
import time
import zipfile
from datetime import date, datetime, timedelta, timezone
from typing import Iterator, List, Optional

import requests

from . import schema
from .config import CFG


class SourceUnavailable(RuntimeError):
    """The endpoint refused us (geo-block, 451, 403, DNS...). Never silently
    substitute a different source: the caller must report it."""


# ---------------------------------------------------------------------------
# URLs
# ---------------------------------------------------------------------------
def daily_url(symbol: str, d: date, market: str = "um") -> str:
    f = "%s-aggTrades-%s.zip" % (symbol, d.isoformat())
    return "%s/data/futures/%s/daily/aggTrades/%s/%s" % (
        CFG.archive_base, market, symbol, f)


def kline_url(symbol: str, interval: str, d: date, market: str = "um") -> str:
    f = "%s-%s-%s.zip" % (symbol, interval, d.isoformat())
    return "%s/data/futures/%s/daily/klines/%s/%s/%s" % (
        CFG.archive_base, market, symbol, interval, f)


def fetch_to_disk(url: str, dest: str) -> Optional[str]:
    """Download once, atomically. Returns None when the object does not exist
    (404) — that is a *missing archive file*, which is reported, never treated
    as evidence that no trades occurred."""
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return dest
    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    for attempt in range(CFG.retry_max):
        try:
            with requests.get(url, stream=True, timeout=CFG.http_timeout) as r:
                if r.status_code == 404:
                    return None
                if r.status_code in (403, 451):
                    raise SourceUnavailable("HTTP %d for %s" % (r.status_code, url))
                r.raise_for_status()
                tmp = dest + ".part"
                with open(tmp, "wb") as fh:
                    for chunk in r.iter_content(1 << 20):
                        fh.write(chunk)
                os.replace(tmp, dest)
                return dest
        except SourceUnavailable:
            raise
        except requests.RequestException:
            if attempt == CFG.retry_max - 1:
                raise
            time.sleep(2 ** attempt)
    return None


# ---------------------------------------------------------------------------
# archive CSV
# ---------------------------------------------------------------------------
class AggArchiveFile(object):
    """Streams one daily archive ZIP as canonical rows.

    Usage:
        f = AggArchiveFile(path)
        for row in f:            # validates every row
            ...
        f.stats, f.unit, f.header
    """

    def __init__(self, path: str, validate_window: bool = True):
        self.path = path
        self.unit = None
        self.header = None
        self.idx = None
        day = schema.day_ms_from_filename(path)
        self.validator = schema.RowValidator(
            day_ms=day if validate_window else None)

    def stats(self) -> dict:
        d = dict(self.validator.stats)
        d["unit"] = self.unit
        d["header"] = list(self.header) if self.header else None
        return d

    def _open(self):
        z = zipfile.ZipFile(self.path)
        name = z.namelist()[0]
        fh = z.open(name)
        return z, io.TextIOWrapper(fh, encoding="utf-8", newline="")

    def __iter__(self) -> Iterator[schema.Row]:
        z, text = self._open()
        try:
            reader = csv.reader(text)
            first = None
            for raw in reader:
                if not raw or not "".join(raw).strip():
                    continue
                first = raw
                break
            if first is None:
                return

            header = first if schema.looks_like_header(first) else None
            if header is not None:
                self.header = header
                self.idx = schema.header_index(header)
            else:
                # No header: fall back to the documented positional contract,
                # but the validator will reject the file if it is wrong.
                self.idx = dict(schema.POSITIONAL_POS if hasattr(
                    schema, "POSITIONAL_POS") else
                    {n: i for i, n in enumerate(schema.AGG_COLUMNS)})

            rows = [] if header is not None else [first]
            for raw in reader:
                if not raw or not "".join(raw).strip():
                    continue
                rows.append(raw)
                if len(rows) >= 5000:
                    for r in self._convert(rows):
                        yield r
                    rows = []
            for r in self._convert(rows):
                yield r
        finally:
            try:
                text.close()
            except Exception:
                pass
            z.close()

    def _convert(self, rows: List[List[str]]) -> Iterator[schema.Row]:
        for raw in rows:
            if len(raw) != len(schema.AGG_COLUMNS):
                raise schema.SchemaError(
                    "column count %d != %d in %s: %r"
                    % (len(raw), len(schema.AGG_COLUMNS),
                       os.path.basename(self.path), raw[:8]))
            if self.unit is None:
                self.unit = schema.detect_ts_unit(
                    int(raw[self.idx["transact_time"]]))
            row = schema.row_from_fields(raw, self.idx, self.unit)
            yield self.validator.check(row)


# ---------------------------------------------------------------------------
# kline archive
# ---------------------------------------------------------------------------
KLINE_COLUMNS = ("open_time", "open", "high", "low", "close", "volume",
                 "close_time", "quote_volume", "count", "taker_buy_volume",
                 "taker_buy_quote_volume", "ignore")


def parse_kline_zip(path: str) -> List[dict]:
    """Return [{open_time, open, high, low, close, volume, count,
    taker_buy_volume}] with open_time normalised to ms."""
    out = []
    with zipfile.ZipFile(path) as z:
        with z.open(z.namelist()[0]) as fh:
            for raw in csv.reader(io.TextIOWrapper(fh, encoding="utf-8")):
                if not raw or not "".join(raw).strip():
                    continue
                if schema.looks_like_header(raw):
                    continue
                if len(raw) < len(KLINE_COLUMNS):
                    raise schema.SchemaError(
                        "kline row has %d columns: %r" % (len(raw), raw[:6]))
                unit = schema.detect_ts_unit(int(raw[0]))
                out.append({
                    "open_time": schema.to_ms(int(raw[0]), unit),
                    "open": float(raw[1]), "high": float(raw[2]),
                    "low": float(raw[3]), "close": float(raw[4]),
                    "volume": float(raw[5]),
                    "count": int(float(raw[8])),
                    "taker_buy_volume": float(raw[9]),
                })
    out.sort(key=lambda r: r["open_time"])
    return out


# ---------------------------------------------------------------------------
# REST
# ---------------------------------------------------------------------------
class RestClient(object):
    def __init__(self, base: Optional[str] = None):
        self.base = base or CFG.rest_base
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "btcof/1.1"})

    def ping(self) -> bool:
        try:
            r = self.session.get(self.base + "/fapi/v1/ping", timeout=10)
            if r.status_code in (403, 451):
                raise SourceUnavailable("REST blocked: HTTP %d" % r.status_code)
            return r.status_code == 200
        except requests.RequestException as e:
            raise SourceUnavailable("REST unreachable: %r" % (e,))

    def agg_trades(self, symbol: str, from_id: Optional[int] = None,
                   limit: int = 1000) -> List[schema.Row]:
        params = {"symbol": symbol, "limit": limit}
        if from_id is not None:
            params["fromId"] = from_id
        for attempt in range(CFG.retry_max):
            r = self.session.get(self.base + "/fapi/v1/aggTrades",
                                 params=params, timeout=CFG.http_timeout)
            if r.status_code in (403, 451):
                raise SourceUnavailable(
                    "REST aggTrades blocked (HTTP %d). This environment cannot "
                    "use binance.com endpoints; archived data still works."
                    % r.status_code)
            if r.status_code == 200:
                time.sleep(0.05)
                return [schema.row_from_rest(o, require_trade_ids=True)
                        for o in r.json()]
            if r.status_code in (418, 429):
                time.sleep(int(r.headers.get("Retry-After", 5)))
                continue
            if r.status_code >= 500 and attempt < CFG.retry_max - 1:
                time.sleep(2 ** attempt)
                continue
            raise RuntimeError("aggTrades HTTP %d: %s"
                               % (r.status_code, r.text[:200]))
        return []


# ---------------------------------------------------------------------------
# time helpers
# ---------------------------------------------------------------------------
def utcnow_ms() -> int:
    return int(datetime.now(timezone.utc).timestamp() * 1000)


def daterange(start: date, end: date):
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)
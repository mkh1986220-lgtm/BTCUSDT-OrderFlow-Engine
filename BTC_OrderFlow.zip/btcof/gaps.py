"""Gap analysis — three separate questions, never conflated:

  A. ARCHIVE COVERAGE : which daily files were never published / never loaded.
                        A missing file is UNKNOWN, not "no trades".
  B. ID CONTINUITY    : holes in agg_trade_id => prints we do not have.
  C. TIME CONTINUITY  : (i) M30 buckets with zero prints inside the covered
                            range, (ii) unusually long silences between prints.

Reporting them separately matters: a missing file creates B and C anomalies,
but the file itself being absent is not evidence about the market.
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Dict, List, Optional

from . import schema


def archive_coverage(conn, symbol: str, start: date, end: date) -> Dict:
    """Classify every day in the window.

    status:
      ok            - file loaded and rows stored
      missing_file  - no archive file; data MAY still arrive via REST/WS
      not_loaded    - file exists but was never ingested in this DB
      no_data       - no rows for that day (unknown, not "no trades")
    """
    days = []
    d = start
    min_ts, max_ts = conn.execute(
        "SELECT MIN(ts) a, MAX(ts) b FROM agg_trades WHERE symbol=?",
        (symbol,)).fetchone()
    have_by_day = {}
    if min_ts is not None:
        for r in conn.execute(
                "SELECT ts/86400000 AS day, COUNT(*) c FROM agg_trades "
                "WHERE symbol=? GROUP BY ts/86400000", (symbol,)):
            have_by_day[r["day"]] = r["c"]

    first_day = schema.utc_day(min_ts) if min_ts is not None else None
    last_day = schema.utc_day(max_ts) if max_ts is not None else None

    while d <= end:
        tag = "archive:%s:%s" % (symbol, d.isoformat())
        row = conn.execute("SELECT rows,detail FROM ingest_log WHERE source=?",
                           (tag,)).fetchone()
        dayno = int(schema.day_ms(d) // 86_400_000)
        rows_in_db = have_by_day.get(dayno, 0)

        if rows_in_db:
            status = "ok"
        elif row is not None and (row["detail"] or "").startswith("file not published"):
            status = "missing_file"
        elif row is not None:
            status = "no_data"
        elif first_day is not None and first_day <= d <= last_day:
            # inside the covered range with zero prints: a real data hole
            status = "no_data"
        else:
            # never fetched at all: we simply do not know
            status = "not_loaded"

        days.append({"day": d.isoformat(), "status": status,
                     "rows": rows_in_db})
        d += timedelta(days=1)

    missing = [x["day"] for x in days if x["status"] in ("missing_file", "not_loaded")]
    return {"days": days, "missing_files": missing,
            "n_days": len(days), "n_missing": len(missing)}


def continuity(conn, symbol: str, tf_minutes: int = 30,
               silence_ms: int = 60_000) -> Dict:
    """Single pass over the tape, ordered by time.

    Returns id-gap statistics, bucket coverage and silence statistics.
    """
    tf_ms = tf_minutes * 60_000
    cur = conn.execute(
        "SELECT agg_id, ts FROM agg_trades WHERE symbol=? ORDER BY ts, agg_id",
        (symbol,))

    prev_id = prev_ts = prev_bucket = None
    id_gaps = 0
    id_missing = 0
    id_examples = []
    silences = 0
    max_silence = 0
    max_silence_at = None
    buckets_present = set()
    first_ts = last_ts = None
    n = 0

    for agg_id, ts in cur:
        n += 1
        if first_ts is None:
            first_ts = ts
        last_ts = ts
        if prev_id is not None and agg_id > prev_id + 1:
            gap = agg_id - prev_id - 1
            id_gaps += 1
            id_missing += gap
            if len(id_examples) < 5:
                id_examples.append({"after_id": prev_id, "next_id": agg_id,
                                    "missing": gap, "ts": ts})
        if prev_ts is not None:
            dt = ts - prev_ts
            if dt > silence_ms:
                silences += 1
                if dt > max_silence:
                    max_silence, max_silence_at = dt, ts
        bucket = ts - (ts % tf_ms)
        if bucket != prev_bucket:
            buckets_present.add(bucket)
            prev_bucket = bucket
        prev_id, prev_ts = agg_id, ts

    if first_ts is None:
        return {"rows": 0}

    first_b = first_ts - (first_ts % tf_ms)
    last_b = last_ts - (last_ts % tf_ms)
    expected = (last_b - first_b) // tf_ms + 1
    empty = expected - len(buckets_present)
    empty_list = []
    if empty:
        b = first_b
        while b <= last_b:
            if b not in buckets_present and len(empty_list) < 10:
                empty_list.append(b)
            b += tf_ms

    return {
        "rows": n,
        "first_ts": first_ts,
        "last_ts": last_ts,
        # B. id continuity
        "id_gap_events": id_gaps,
        "id_missing_total": id_missing,
        "id_gap_examples": id_examples,
        # C. time continuity
        "buckets_expected": expected,
        "buckets_present": len(buckets_present),
        "empty_buckets": empty,
        "empty_bucket_examples": empty_list,
        "silences_over_threshold": silences,
        "silence_threshold_ms": silence_ms,
        "max_silence_ms": max_silence,
        "max_silence_at": max_silence_at,
    }


def duplicates(conn, symbol: str) -> Dict:
    row = conn.execute(
        "SELECT COALESCE(SUM(dupes),0) d, COALESCE(SUM(conflicts),0) c, "
        "COALESCE(SUM(rows),0) r FROM ingest_log WHERE symbol=?",
        (symbol,)).fetchone()
    stored = conn.execute("SELECT COUNT(*) c FROM agg_trades WHERE symbol=?",
                          (symbol,)).fetchone()["c"]
    return {"duplicate_rows_rejected": row["d"],
            "conflicting_rows": row["c"],
            "rows_written": row["r"],
            "rows_stored": stored}


def report(conn, symbol: str, tf_minutes: int, start: date, end: date,
           silence_ms: int = 60_000) -> Dict:
    cov = archive_coverage(conn, symbol, start, end)
    cont = continuity(conn, symbol, tf_minutes, silence_ms)
    dup = duplicates(conn, symbol)
    return {"coverage": cov, "continuity": cont, "duplicates": dup}
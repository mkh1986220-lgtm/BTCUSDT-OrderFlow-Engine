"""Validation: per-bar comparison against Binance's own published klines.

The archive klines carry `volume`, `count` (number of raw trades) and
`taker_buy_volume`. Those three let us prove, bar by bar, that:
  * we have every trade (count),
  * the buy/sell split is right (taker_buy_volume == our buy_vol),
  * prices and volumes were read from the right columns.

A single "99% match" headline hides which bars are wrong, so this reports the
diff for EVERY bar and the worst offenders with their signs.
"""
from __future__ import annotations

from datetime import date
from typing import Dict, List, Optional

from . import db, orderflow, schema, sources
from .config import CFG


def kline_day(conn, symbol: str, d: date, tf_minutes: int = 30,
              tol_vol: float = 1e-9) -> Dict:
    dest = CFG.path("%s/%s-%dm-%s.zip" % (CFG.raw_dir, symbol, tf_minutes,
                                          d.isoformat()))
    try:
        path = sources.fetch_to_disk(
            sources.kline_url(symbol, "%dm" % tf_minutes, d), dest)
    except sources.SourceUnavailable as e:
        return {"day": d.isoformat(), "status": "blocked", "detail": str(e)}
    if path is None:
        return {"day": d.isoformat(), "status": "missing"}

    ref = sources.parse_kline_zip(path)
    if not ref:
        return {"day": d.isoformat(), "status": "empty"}

    start = ref[0]["open_time"]
    bars = orderflow.build_bars(conn, symbol, tf_minutes, start_ms=start,
                                end_ms=start + 86_400_000,
                                big_qty=CFG.big_qty, with_annotations=False)
    mine = dict((b.open_time, b) for b in bars)

    rows = []
    for r in ref:
        b = mine.get(r["open_time"])
        item = {"open_time": r["open_time"], "status": "missing_bar"}
        if b is not None:
            dp = max(abs(b.open - r["open"]), abs(b.high - r["high"]),
                     abs(b.low - r["low"]), abs(b.close - r["close"]))
            dv = abs(b.volume - r["volume"])
            dtb = abs(b.buy_vol - r["taker_buy_volume"])
            dcount = b.trades - r["count"]
            rel_v = dv / r["volume"] if r["volume"] else 0.0
            rel_tb = dtb / r["taker_buy_volume"] if r["taker_buy_volume"] else 0.0
            item.update({
                "status": "exact" if (dp <= 1e-9 and rel_v <= tol_vol
                                      and rel_tb <= tol_vol and dcount == 0)
                          else "diff",
                "price_abs": dp,
                "volume_rel": rel_v,
                "taker_buy_rel": rel_tb,
                "volume_signed": b.volume - r["volume"],
                "taker_buy_signed": b.buy_vol - r["taker_buy_volume"],
                "count_delta": dcount,
                "o_ours": b.open, "o_ref": r["open"],
                "v_ours": b.volume, "v_ref": r["volume"],
            })
        rows.append(item)

    exact = [x for x in rows if x["status"] == "exact"]
    worst_v = max(rows, key=lambda x: x.get("volume_rel", 0))
    worst_p = max(rows, key=lambda x: x.get("price_abs", 0))
    worst_c = max(rows, key=lambda x: abs(x.get("count_delta", 0)))
    return {
        "day": d.isoformat(), "status": "ok",
        "bars_ref": len(ref), "bars_ours": len(bars),
        "exact": len(exact), "differing": len(rows) - len(exact),
        "missing_bar": sum(1 for x in rows if x["status"] == "missing_bar"),
        "volume_match_pct": 100.0 * len(exact) / len(rows),
        "worst_volume_rel": worst_v.get("volume_rel", 0),
        "worst_volume_at": worst_v["open_time"],
        "worst_volume_signed": worst_v.get("volume_signed", 0),
        "worst_price_abs": worst_p.get("price_abs", 0),
        "worst_price_at": worst_p["open_time"],
        "worst_count_delta": worst_c.get("count_delta", 0),
        "count_mismatched_bars": sum(1 for x in rows if x.get("count_delta")),
        "rows": rows,
    }


def kline_report(conn, symbol: str, days: List[date],
                 tf_minutes: int = 30) -> Dict:
    out = []
    for d in days:
        r = kline_day(conn, symbol, d, tf_minutes)
        out.append(r)
    ok = [r for r in out if r.get("status") == "ok"]
    total_bars = sum(r["bars_ref"] for r in ok)
    total_exact = sum(r["exact"] for r in ok)
    return {
        "days": out,
        "days_checked": len(ok),
        "bars_checked": total_bars,
        "bars_exact": total_exact,
        "volume_match_pct": (100.0 * total_exact / total_bars) if total_bars else None,
        "worst_volume_rel": max([r["worst_volume_rel"] for r in ok] or [0]),
        "count_mismatched_bars": sum(r["count_mismatched_bars"] for r in ok),
        "worst_price_abs": max([r["worst_price_abs"] for r in ok] or [0]),
    }


def integrity(conn, symbol: str) -> Dict:
    r = conn.execute(
        "SELECT COUNT(*) n, MIN(agg_id) a, MAX(agg_id) b, MIN(ts) t0, "
        "MAX(ts) t1, SUM(qty) q FROM agg_trades WHERE symbol=?",
        (symbol,)).fetchone()
    if not r["n"]:
        return {"status": "no-data"}
    bad = conn.execute(
        "SELECT COUNT(*) c FROM agg_trades WHERE symbol=? AND "
        "(price<=0 OR qty<=0 OR first_tid>last_tid OR is_buyer_maker NOT IN (0,1))",
        (symbol,)).fetchone()["c"]
    return {
        "status": "ok",
        "agg_trades": r["n"],
        "agg_id_range": [r["a"], r["b"]],
        "agg_id_span": r["b"] - r["a"] + 1,
        "ts_range": [r["t0"], r["t1"]],
        "total_qty": round(r["q"], 6),
        "invalid_rows": bad,
        "first_day": schema.utc_day(r["t0"]).isoformat(),
        "last_day": schema.utc_day(r["t1"]).isoformat(),
    }
from __future__ import annotations

import argparse
import datetime as dt
import json
from typing import Optional

from . import cvd, db, downloader, gaps, orderflow, schema, validate
from .config import CFG


def _d(s):
    return dt.datetime.strptime(s, "%Y-%m-%d").date()


def _ts(ms):
    return dt.datetime.fromtimestamp(ms / 1000.0, tz=dt.timezone.utc).strftime(
        "%Y-%m-%d %H:%M")


def cmd_selftest(a):
    from .selftest import main as sm
    raise SystemExit(sm())


def cmd_download(a):
    CFG.ensure_dirs()
    with db.session(CFG.path(CFG.db_path)) as conn:
        res = downloader.ingest_range(conn, CFG.symbol, _d(a.start), _d(a.end))
        ok = sum(1 for r in res if r["status"] == "ok")
        miss = [r["source"] for r in res if r["status"] == "missing"]
        blocked = [r for r in res if r["status"] == "blocked"]
        bad = [r for r in res if r["status"] == "schema_error"]
        print("[download] ok=%d missing=%d blocked=%d schema_errors=%d"
              % (ok, len(miss), len(blocked), len(bad)))
        for m in miss:
            print("           missing archive:", m)
        print("[download] last_agg_id=%s" % db.last_agg_id(conn, CFG.symbol))


def cmd_build(a):
    with db.session(CFG.path(CFG.db_path)) as conn:
        bars = orderflow.build_bars(conn, CFG.symbol, CFG.tf_minutes,
                                    big_qty=CFG.big_qty)
        n = orderflow.persist_bars(conn, CFG.symbol, CFG.tf_minutes, bars)
    print("[build] %d bars, %d upserted" % (len(bars), n))
    print("  open_time(UTC)      close     volume   buy_vol  sell_vol    delta"
          "   d%      cvd")
    for b in bars[-a.tail:]:
        print("  %s %9.1f %10.3f %9.3f %9.3f %8.3f %6.1f %10.1f"
              % (_ts(b.open_time), b.close, b.volume, b.buy_vol, b.sell_vol,
                 b.delta, b.delta_pct, b.cvd_close))


def cmd_cvd(a):
    with db.session(CFG.path(CFG.db_path)) as conn:
        if a.mode == "rebuild":
            r = cvd.rebuild(conn, CFG.symbol, CFG.tf_minutes)
        elif a.mode == "continue":
            r = cvd.continue_(conn, CFG.symbol, CFG.tf_minutes)
        else:
            r = cvd.compare(conn, CFG.symbol, CFG.tf_minutes, a.ratio)
        r.pop("bars_list", None)
        print(json.dumps(r, indent=2, default=str))


def cmd_gaps(a):
    with db.session(CFG.path(CFG.db_path)) as conn:
        rep = gaps.report(conn, CFG.symbol, CFG.tf_minutes, _d(a.start), _d(a.end))
        print("A. archive coverage")
        for d in rep["coverage"]["days"]:
            print("   %s  %-13s rows=%s" % (d["day"], d["status"], d["rows"]))
        c = rep["continuity"]
        print("B. id continuity   gap_events=%s missing_ids=%s examples=%s"
              % (c["id_gap_events"], c["id_missing_total"], c["id_gap_examples"][:2]))
        print("C. time continuity empty_buckets=%s/%s  silences>%sms=%s  max_silence=%sms"
              % (c["empty_buckets"], c["buckets_expected"],
                 c["silence_threshold_ms"], c["silences_over_threshold"],
                 c["max_silence_ms"]))
        print("D. duplicates      %s" % rep["duplicates"])


def cmd_kline(a):
    with db.session(CFG.path(CFG.db_path)) as conn:
        days = [_d(x) for x in a.days]
        rep = validate.kline_report(conn, CFG.symbol, days, CFG.tf_minutes)
        for d in rep["days"]:
            if d.get("status") != "ok":
                print("  %s -> %s" % (d["day"], d.get("status")))
                continue
            print("  %s  bars=%d exact=%d differing=%d worst_vol_rel=%.3g "
                  "worst_price=%.4g count_mismatch_bars=%d"
                  % (d["day"], d["bars_ref"], d["exact"], d["differing"],
                     d["worst_volume_rel"], d["worst_price_abs"],
                     d["count_mismatched_bars"]))
        print(json.dumps({k: v for k, v in rep.items() if k != "days"},
                         indent=2, default=str))


def cmd_stream(a):
    from .stream import run_live
    print(json.dumps(run_live(CFG.path(CFG.db_path), a.seconds), indent=2,
                     default=str))


def cmd_profile(a):
    with db.session(CFG.path(CFG.db_path)) as conn:
        print(json.dumps(orderflow.big_qty_profile(conn, CFG.symbol), indent=2))


def cmd_report(a):
    """The end-to-end report required for the 10-day check."""
    CFG.ensure_dirs()
    with db.session(CFG.path(CFG.db_path)) as conn:
        integ = validate.integrity(conn, CFG.symbol)
        bars = orderflow.build_bars(conn, CFG.symbol, CFG.tf_minutes,
                                    big_qty=CFG.big_qty, with_annotations=False)
        gap = gaps.report(conn, CFG.symbol, CFG.tf_minutes, _d(a.start), _d(a.end))
        cvdcmp = cvd.compare(conn, CFG.symbol, CFG.tf_minutes, a.ratio)
        kl = validate.kline_report(conn, CFG.symbol,
                                   [_d(x) for x in a.days] if a.days else [],
                                   CFG.tf_minutes)

    buy = sum(b.buy_vol for b in bars)
    sell = sum(b.sell_vol for b in bars)
    rep = {
        "symbol": CFG.symbol,
        "window": [a.start, a.end],
        "agg_trades": integ["agg_trades"],
        "m30_bars": len(bars),
        "buy_volume_btc": round(buy, 6),
        "sell_volume_btc": round(sell, 6),
        "volume_btc": round(buy + sell, 6),
        "delta_btc": round(buy - sell, 6),
        "cvd_last": round(bars[-1].cvd_close, 6) if bars else None,
        "first_bar": _ts(bars[0].open_time) if bars else None,
        "last_bar": _ts(bars[-1].open_time) if bars else None,
        "duplicates": gap["duplicates"],
        "id_gap_events": gap["continuity"]["id_gap_events"],
        "id_missing_total": gap["continuity"]["id_missing_total"],
        "empty_buckets": gap["continuity"]["empty_buckets"],
        "buckets_expected": gap["continuity"]["buckets_expected"],
        "missing_archive_files": gap["coverage"]["missing_files"],
        "cvd_rebuild_vs_continue": {
            "equal": cvdcmp.get("equal"),
            "cvd_rebuild": round(cvdcmp.get("cvd_rebuild", 0), 6),
            "cvd_continue": round(cvdcmp.get("cvd_continue", 0), 6),
            "mismatches": cvdcmp.get("mismatch_count"),
        },
        "kline": {k: v for k, v in kl.items() if k != "days"},
    }
    print(json.dumps(rep, indent=2, default=str))


def main(argv=None):
    p = argparse.ArgumentParser("btcof", description="BTC M30 order-flow data engine")
    p.add_argument("--db", default=None, help="override database path")
    p.add_argument("--root", default=None, help="project root (default: cwd)")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("selftest"); s.set_defaults(fn=cmd_selftest)

    s = sub.add_parser("download")
    s.add_argument("--start", required=True); s.add_argument("--end", required=True)
    s.set_defaults(fn=cmd_download)

    s = sub.add_parser("build"); s.add_argument("--tail", type=int, default=8)
    s.set_defaults(fn=cmd_build)

    s = sub.add_parser("cvd")
    s.add_argument("--mode", choices=("rebuild", "continue", "compare"),
                   default="compare")
    s.add_argument("--ratio", type=float, default=0.7)
    s.set_defaults(fn=cmd_cvd)

    s = sub.add_parser("gaps")
    s.add_argument("--start", required=True); s.add_argument("--end", required=True)
    s.set_defaults(fn=cmd_gaps)

    s = sub.add_parser("kline"); s.add_argument("--days", nargs="+", required=True)
    s.set_defaults(fn=cmd_kline)

    s = sub.add_parser("stream"); s.add_argument("--seconds", type=int, default=3600)
    s.set_defaults(fn=cmd_stream)

    s = sub.add_parser("profile"); s.set_defaults(fn=cmd_profile)

    s = sub.add_parser("report")
    s.add_argument("--start", required=True); s.add_argument("--end", required=True)
    s.add_argument("--days", nargs="*", default=[])
    s.add_argument("--ratio", type=float, default=0.7)
    s.set_defaults(fn=cmd_report)

    a = p.parse_args(argv)
    if a.root:
        object.__setattr__(CFG, "root", a.root)
    if a.db:
        object.__setattr__(CFG, "db_path", a.db)
    a.fn(a)
"""CVD: full rebuild and crash-safe continuation, plus the equivalence check.

Definitions
-----------
* rebuild()  : CVD from the very first stored aggTrade, anchored at 0.
* continue_(): CVD from the last saved checkpoint. The checkpoint stores the
  bar's open time, the CVD at that bar's open, and the CVD/last id at its
  close. Continuation therefore re-cuts the final (possibly partial) bar
  instead of appending a half bar — that is what makes it exactly equal to a
  rebuild rather than approximately equal.

A checkpoint is only trusted if the row it points at still exists with the same
timestamp; otherwise `stale` is returned and the caller must rebuild.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from . import db, orderflow
from .config import CFG


def rebuild(conn, symbol: str, tf_minutes: int = 30, big_qty: Optional[float] = None,
            persist: bool = True, with_annotations: bool = False) -> Dict:
    """Compute CVD over the whole stored history and checkpoint the last bar."""
    big_qty = CFG.big_qty if big_qty is None else big_qty
    bars = orderflow.build_bars(conn, symbol, tf_minutes, big_qty=big_qty,
                                with_annotations=with_annotations, cvd_base=0.0)
    if not bars:
        return {"status": "empty", "bars": 0, "cvd": 0.0}
    if persist:
        orderflow.persist_bars(conn, symbol, tf_minutes, bars)
        b = bars[-1]
        db.save_checkpoint(conn, symbol, tf_minutes, b.open_time,
                           b.cvd_close, b.last_agg_id or 0, b.last_ts or 0,
                           cvd_open=b.cvd_open)
        conn.commit()
    return {"status": "ok", "bars": len(bars), "cvd": bars[-1].cvd_close,
            "first_bar": bars[0].open_time, "last_bar": bars[-1].open_time,
            "bars_list": bars}


def continue_(conn, symbol: str, tf_minutes: int = 30,
              big_qty: Optional[float] = None, persist: bool = True,
              with_annotations: bool = False) -> Dict:
    """Resume CVD from the checkpoint. Returns status 'stale' if the checkpoint
    no longer matches the stored tape (then the caller must rebuild)."""
    big_qty = CFG.big_qty if big_qty is None else big_qty
    cp = db.load_checkpoint(conn, symbol, tf_minutes)
    if cp is None:
        r = rebuild(conn, symbol, tf_minutes, big_qty, persist,
                    with_annotations)
        r["status"] = "rebuilt (no checkpoint)"
        return r

    row = conn.execute("SELECT ts FROM agg_trades WHERE symbol=? AND agg_id=?",
                       (symbol, cp["last_agg_id"])).fetchone()
    if row is None or row["ts"] != cp["last_ts"]:
        return {"status": "stale", "checkpoint": cp,
                "detail": "checkpoint row missing or moved"}

    late = conn.execute(
        "SELECT COUNT(*) c FROM agg_trades WHERE symbol=? AND agg_id<=? AND ts>?",
        (symbol, cp["last_agg_id"], cp["last_ts"])).fetchone()["c"]
    if late:
        return {"status": "stale", "checkpoint": cp,
                "detail": "%d rows inserted inside the counted range" % late}

    bars = orderflow.build_bars(conn, symbol, tf_minutes,
                                start_ms=cp["bar_open_time"],
                                cvd_base=cp["cvd_open"],
                                big_qty=big_qty,
                                with_annotations=with_annotations)
    if not bars:
        return {"status": "up-to-date", "bars": 0, "cvd": cp["cvd_value"]}
    if persist:
        orderflow.persist_bars(conn, symbol, tf_minutes, bars)
        b = bars[-1]
        db.save_checkpoint(conn, symbol, tf_minutes, b.open_time,
                           b.cvd_close, b.last_agg_id or 0, b.last_ts or 0,
                           cvd_open=b.cvd_open)
        conn.commit()
    return {"status": "ok", "bars": len(bars), "cvd": bars[-1].cvd_close,
            "resumed_from": cp["bar_open_time"], "bars_list": bars}


def compare(conn, symbol: str, tf_minutes: int = 30,
            split_ratio: float = 0.7) -> Dict:
    """Rebuild vs Continue on the SAME dataset.

    The tape is split at `split_ratio`; a checkpoint is taken at the end of the
    first part; continuation then runs on the full tape. The result is compared
    bar by bar against a full rebuild.
    """
    span = conn.execute("SELECT MIN(ts) a, MAX(ts) b FROM agg_trades "
                        "WHERE symbol=?", (symbol,)).fetchone()
    if span["a"] is None:
        return {"equal": False, "detail": "no data"}
    split_ms = int(span["a"] + (span["b"] - span["a"]) * split_ratio)
    tf_ms = tf_minutes * 60_000
    split_ms -= split_ms % tf_ms            # align to a bar boundary

    head = orderflow.build_bars(conn, symbol, tf_minutes, end_ms=split_ms,
                                big_qty=CFG.big_qty, with_annotations=False)
    if not head:
        return {"equal": False, "detail": "empty head"}
    cp_bar = head[-1]

    full = orderflow.build_bars(conn, symbol, tf_minutes,
                                big_qty=CFG.big_qty, with_annotations=False)
    cont = orderflow.build_bars(conn, symbol, tf_minutes,
                                start_ms=cp_bar.open_time,
                                cvd_base=cp_bar.cvd_open,
                                big_qty=CFG.big_qty, with_annotations=False)

    full_idx = dict((b.open_time, b) for b in full)
    mismatches = []
    for b in cont:
        f = full_idx.get(b.open_time)
        if f is None:
            mismatches.append({"open_time": b.open_time, "issue": "missing in rebuild"})
            continue
        for field in ("open", "high", "low", "close", "volume", "buy_vol",
                      "sell_vol", "delta", "cvd_open", "cvd_close"):
            a, c = getattr(f, field), getattr(b, field)
            if a is None or c is None:
                continue
            if abs(a - c) > 1e-9 * max(1.0, abs(a)):
                mismatches.append({"open_time": b.open_time, "field": field,
                                   "rebuild": a, "continue": c})
                break

    return {
        "equal": not mismatches and abs(full[-1].cvd_close - cont[-1].cvd_close) < 1e-9,
        "split_ms": split_ms,
        "bars_total": len(full),
        "bars_rebuilt_from_checkpoint": len(cont),
        "cvd_rebuild": full[-1].cvd_close,
        "cvd_continue": cont[-1].cvd_close,
        "mismatches": mismatches[:5],
        "mismatch_count": len(mismatches),
    }
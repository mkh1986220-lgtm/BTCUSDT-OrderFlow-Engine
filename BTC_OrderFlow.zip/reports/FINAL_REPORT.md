# BTCUSDT USDⓈ-M — Order Flow Engine v1.1 — Final Test Report
Status: **NOT APPROVED** (one open item: 2026-10-27 archive inconsistency)

## 1. Data actually loaded
11 daily archive files, 2026-10-20 .. 2026-10-31 (2026-10-28 not published, HTTP 404).
AggTrades stored: **12,185,438**. Duplicates rejected: 0. Conflicting rows: 0.
Timestamp unit detected: ms in every file.

## 2. Daily match vs official klines (volume / taker-buy)
| day | vol ours | vol kline | diff % | buy ours | buy kline | diff % |
|---|---|---|---|---|---|---|
| 2026-10-20 | 139,044.818 | 139,044.818 | 0.00000 | 70,134.912 | 70,134.912 | 0.00000 |
| 2026-10-21 | 150,823.352 | 150,823.352 | 0.00000 | 77,825.683 | 77,825.683 | 0.00000 |
| 2026-10-22 | 176,119.659 | 176,119.659 | 0.00000 | 83,838.284 | 83,838.284 | 0.00000 |
| 2026-10-23 | 111,566.210 | 111,566.210 | 0.00000 | 55,887.115 | 55,887.115 | 0.00000 |
| 2026-10-24 | 110,896.476 | 110,896.476 | 0.00000 | 54,253.077 | 54,253.077 | 0.00000 |
| 2026-10-25 | 68,809.681 | 68,809.674 | +0.00001 | 33,218.308 | 33,218.308 | 0.00000 |
| 2026-10-26 | 131,321.130 | 131,321.137 | -0.00001 | 66,872.894 | 66,872.894 | 0.00000 |
| 2026-10-27 | 101,256.511 | 102,554.645 | **-1.26580** | 49,556.787 | 50,355.434 | **-1.58602** |
| 2026-10-29 | 253,736.267 | 253,736.138 | +0.00005 | 121,922.433 | 121,922.433 | 0.00000 |
| 2026-10-30 | 241,630.694 | 241,630.823 | -0.00005 | 117,172.624 | 117,172.624 | 0.00000 |
| 2026-10-31 | 51,187.090 | 51,187.090 | 0.00000 | 25,481.652 | 25,481.652 | 0.00000 |
| **TOTAL** | **1,536,391.888** | **1,537,690.022** | **-0.08442** | **756,163.769** | **756,962.416** | **-0.10551** |

## 3. Per-bar match, 480 bars (all days except 2026-10-27)
| field | max abs | mean abs | max % | mean % | within 0.001% |
|---|---|---|---|---|---|
| open | 0.2000 | 0.004375 | 0.000240 | 0.000005 | 480/480 |
| high | 0.0000 | 0.000000 | 0.000000 | 0.000000 | 480/480 |
| low | 0.0000 | 0.000000 | 0.000000 | 0.000000 | 480/480 |
| close | 0.0000 | 0.000000 | 0.000000 | 0.000000 | 480/480 |
| volume | 1.4770 | 0.015467 | 0.039072 | 0.000628 | 458/480 |
| taker_buy | 1.5030 | 0.011996 | 0.075907 | 0.000739 | 464/480 |

Trade count: **NOT compared.** Daily totals differ by +0.02%..+0.03% in our favour
(2369047 vs 2368515 on 10-24; 5462053 vs 5460608 on 10-30), so the two definitions
are not equivalent and a per-bar comparison would be invalid.

## 4. CVD
- Full rebuild from raw: final **-24,064.35**; 528 bars; **0** mismatches vs stored bars.
- rebuild vs continue (70/30 split): equal, 0 mismatches, both -24064.349999987237.
- Fake bars: **0** rows with zero volume. 2026-10-28 is preserved as Missing Data.
- Effect of 2026-10-28: none on CVD (no bar emitted, no invented zero-delta).
- Effect of 2026-10-27: CVD in that window is missing ~1,297 BTC of true delta.

## 5. Gaps (python main.py gaps)
- Archive coverage: 11 ok, 1 `missing_file` (2026-10-28).
- id continuity: 1 gap event, **961,120** ids missing (after 3498290466 -> 3499251587).
- time continuity: **48 / 576** expected M30 buckets empty; silences > 60 s: 2; max silence 24.00 h.
- duplicates: 0 rejected, 0 conflicting, 12,185,438 written = 12,185,438 stored.
- Expected bars 576, present 528, absent 48 (all on 2026-10-28).

## 6. Open item: 2026-10-27
Archive daily file and monthly file agree: 1,466 rows / 107.445 BTC in 00:00-00:30.
1m and 30m klines agree: 1,404.927 BTC / 42,536 trades.
Last id before the hole 3497450210 @ 00:02:46.494, next 3497450211 @ 00:30:05.857
(adjacent ids). Deficit concentrated in one bar: 1,297.482 of 1,298.134 BTC.
**Verdict: UNDETERMINED.** Requires `tools/rest_probe.py` on a host where
fapi.binance.com is reachable.

## 7. Environment limits
- data.binance.vision: reachable.
- fapi.binance.com / api.binance.com: HTTP 451. fapi1/fapi2: HTTP 302.
- WebSocket handshake: HTTP 101; **zero data frames received in 18 s** on two endpoints.
- REST and live streaming remain **UNVERIFIED**.

## 8. Tests
26 tests. Before packaging: 25 pass, 1 skip (REST blocked).
After extracting the ZIP into a clean directory: 26 run, 25 pass, **2 skip**
(REST blocked; real-archive test skipped because `data/raw/` is not shipped in the ZIP).

# BTCUSDT USDⓈ-M Perpetual — Order Flow Engine v1.1

Stage 1 only: acquisition, storage, validation, order flow.
No strategy, no entries/exits, no backtest, no trading bot.

## What it does
- Downloads official Binance aggTrades archives (`data.binance.vision`), resumable by day and by agg_id.
- Parses archive CSV **by header name** (never by bare position); REST/WS JSON **by key**.
- Normalises timestamps (s/ms/µs/ns) to milliseconds at the boundary; rejects invalid rows instead of storing them.
- Builds M30 bars from real prints: buy/sell volume, total volume, delta, delta %, CVD, aggTrade count, raw trade count, VWAP.
- CVD: full `rebuild` and crash-safe `continue`, with an equality check between them.
- Gap reporting kept in three separate classes: missing archive files, agg_id holes, time holes.
- Per-bar validation against Binance's own published klines (OHLC, volume, taker_buy_volume).
- Live collector: subscribe-first, buffer, REST backfill, contiguous-only merge (no silent holes).

## Install
    pip install -r requirements.txt

Python 3.8+ (aiohttp pinned to 3.8.6 for 3.8 hosts). Nothing runs on your own machine
unless you run it there — the code is pure Python + SQLite.

## Google Colab
```
!pip install -q requests==2.31.0 aiohttp==3.8.6
!mkdir -p /content/btcof && cd /content/btcof
# upload the project zip, then:
!unzip -q btcof_v1.1.zip -d /content
%cd /content/btcof
!python main.py selftest
!python main.py download --start 2026-10-20 --end 2026-10-31
!python main.py build --tail 6
!python main.py cvd --mode compare
!python main.py gaps --start 2026-10-20 --end 2026-10-31
!python main.py kline --days 2026-10-29 2026-10-30
!python main.py report --start 2026-10-20 --end 2026-10-31
```
Colab is ephemeral: mount Drive or re-download. Every command is resumable.

## Linux VPS (permanent)
```
python3 -m venv venv && . venv/bin/activate
pip install -r requirements.txt
export BTCOF_ROOT=/opt/btcof        # data/, logs/, reports/ live here
python main.py download --start 2026-10-01 --end 2026-11-01
nohup python main.py stream --seconds 0 > logs/stream.out 2>&1 &   # 0 = forever
```
Systemd unit (recommended over nohup):
```
[Unit]
Description=btcof stream
[Service]
WorkingDirectory=/opt/btcof
Environment=BTCOF_ROOT=/opt/btcof
ExecStart=/opt/btcof/venv/bin/python main.py stream --seconds 0
Restart=always
RestartSec=10
[Install]
WantedBy=multi-user.target
```

## Recovery after a crash / disconnect
1. `python main.py selftest` — confirm the code is intact.
2. `python main.py download --start <last_day> --end <today>` — already-loaded days are skipped via `ingest_log`, so this is safe to repeat.
3. `python main.py cvd --mode continue` — resumes CVD from the last checkpoint. If the checkpoint is `stale` (rows inserted inside the counted range), it says so; then run `--mode rebuild`.
4. `python main.py gaps --start ... --end ...` — verify nothing was lost.
Duplicates are impossible: `(symbol, agg_id)` is the primary key. Conflicting duplicates (same id, different payload) are counted separately and logged.

## Layout
```
btcof/{config,db,schema,sources,downloader,orderflow,cvd,gaps,stream,validate,selftest,run}.py
main.py  requirements.txt  notebooks/btcof_colab.ipynb  reports/
```

## Known limitations
- REST (`fapi.binance.com`) and live WebSocket **message flow** could not be verified in the
  build environment (HTTP 451 geo-block; WS handshake 101 but zero frames). Treat as UNVERIFIED
  until you run `python main.py stream` on the VPS.
- The official archive for 2026-10-27 is internally inconsistent with Binance's kline archive
  (1,297.482 BTC / ~41,070 trades missing between 00:02:46 and 00:30:05 UTC). Unresolved.

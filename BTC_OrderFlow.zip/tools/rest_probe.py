#!/usr/bin/env python3
"""Standalone REST probe for the 2026-10-27 00:00-00:31 UTC window.

Run this on the Linux VPS (where fapi.binance.com is reachable):

    pip install requests
    python tools/rest_probe.py --symbol BTCUSDT --from-id 3497450210 \
        --start 2026-10-27T00:00:00Z --end 2026-10-27T00:31:00Z --out out_oct27

It writes:
    out_oct27/raw/page_0000.json ...   raw API responses, untouched
    out_oct27/trades.csv               parsed trades
    out_oct27/report.json              totals + comparison + every error
    out_oct27/report.md                human readable summary

Exit codes: 0 = measured, 2 = UNDETERMINED (blocked/error, nothing substituted).
No third-party data is ever used as a stand-in for the REST answer.
"""
import argparse
import csv
import json
import os
import sys
import time
from datetime import datetime, timezone

try:
    import requests
except ImportError:
    sys.stderr.write("pip install requests\n")
    raise SystemExit(3)

BASE = "https://fapi.binance.com"
ARCHIVE = "https://data.binance.vision"


def iso_to_ms(s):
    return int(datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ")
               .replace(tzinfo=timezone.utc).timestamp() * 1000)


def ms_to_iso(ms):
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def fetch_pages(symbol, from_id, start_ms, end_ms, outdir, limit=1000,
                max_pages=200):
    rawdir = os.path.join(outdir, "raw")
    os.makedirs(rawdir, exist_ok=True)
    trades, pages, errors = [], 0, []
    cursor = from_id
    session = requests.Session()
    session.headers.update({"User-Agent": "btcof-restprobe/1.0"})

    for page in range(max_pages):
        params = {"symbol": symbol, "fromId": cursor, "limit": limit}
        url = BASE + "/fapi/v1/aggTrades"
        rec = {"page": page, "url": url, "params": params}
        try:
            r = session.get(url, params=params, timeout=30)
            rec["http_status"] = r.status_code
            rec["headers"] = {k: v for k, v in r.headers.items()
                              if k.lower() in ("content-type", "retry-after",
                                               "x-mbx-used-weight-1m")}
            body = r.text
            rec["body_bytes"] = len(body)
            with open(os.path.join(rawdir, "page_%04d.json" % page), "w",
                      encoding="utf-8") as fh:
                fh.write(body)
        except requests.RequestException as e:
            rec["error"] = repr(e)
            errors.append(rec)
            break

        if r.status_code in (403, 418, 451):
            rec["verdict"] = "BLOCKED"
            errors.append(rec)
            return {"status": "UNDETERMINED", "reason": "HTTP %d" % r.status_code,
                    "pages": pages, "errors": errors, "trades": trades}
        if r.status_code != 200:
            rec["verdict"] = "HTTP_ERROR"
            errors.append(rec)
            break

        try:
            batch = r.json()
        except ValueError as e:
            rec["error"] = "bad json: %r" % (e,)
            errors.append(rec)
            break

        rec["rows"] = len(batch)
        pages += 1
        if not batch:
            rec["verdict"] = "empty"
            errors.append(rec)
            break

        for t in batch:
            trades.append({"agg_id": int(t["a"]), "ts": int(t["T"]),
                           "iso": ms_to_iso(int(t["T"])),
                           "price": float(t["p"]), "qty": float(t["q"]),
                           "first_tid": int(t.get("f", -1)),
                           "last_tid": int(t.get("l", -1)),
                           "is_buyer_maker": 1 if t["m"] else 0})
        if batch[-1]["T"] > end_ms:
            rec["verdict"] = "past_window"
            break
        cursor = batch[-1]["a"] + 1
        if len(batch) < limit:
            rec["verdict"] = "short_page"
            break
        time.sleep(0.1)

    return {"status": "OK", "pages": pages, "errors": errors, "trades": trades}


def klines_1m(symbol, day, start_ms, end_ms, outdir):
    """Reference series. Archive first (free), REST only as a fallback.
    This is used ONLY for comparison; it is never reported as the REST answer."""
    name = "%s-1m-%s.zip" % (symbol, day)
    dest = os.path.join(outdir, name)
    url = "%s/data/futures/um/daily/klines/%s/1m/%s" % (ARCHIVE, symbol, name)
    try:
        r = requests.get(url, timeout=60)
        if r.status_code != 200:
            return {"status": "unavailable", "http_status": r.status_code}
        with open(dest, "wb") as fh:
            fh.write(r.content)
    except requests.RequestException as e:
        return {"status": "error", "detail": repr(e)}

    import csv as _csv
    import io
    import zipfile
    rows = []
    with zipfile.ZipFile(dest) as z:
        with z.open(z.namelist()[0]) as fh:
            for raw in _csv.reader(io.TextIOWrapper(fh, encoding="utf-8")):
                if not raw or not raw[0].strip().isdigit():
                    continue
                t = int(raw[0])
                if t > 10 ** 14:
                    t //= 1000
                if start_ms <= t < end_ms:
                    rows.append({"open_time": t, "volume": float(raw[5]),
                                 "count": int(float(raw[8])),
                                 "taker_buy": float(raw[9])})
    return {"status": "ok", "rows": rows}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbol", default="BTCUSDT")
    ap.add_argument("--from-id", type=int, default=3497450210)
    ap.add_argument("--start", default="2026-10-27T00:00:00Z")
    ap.add_argument("--end", default="2026-10-27T00:31:00Z")
    ap.add_argument("--out", default="out_oct27")
    a = ap.parse_args()

    start_ms, end_ms = iso_to_ms(a.start), iso_to_ms(a.end)
    os.makedirs(a.out, exist_ok=True)

    res = fetch_pages(a.symbol, a.from_id, start_ms, end_ms, a.out)
    trades = [t for t in res.get("trades", [])
              if start_ms <= t["ts"] < end_ms]

    report = {"symbol": a.symbol, "endpoint": BASE + "/fapi/v1/aggTrades",
              "from_id": a.from_id, "window": [a.start, a.end],
              "run_at": datetime.now(timezone.utc).isoformat(),
              "status": res["status"], "pages": res.get("pages", 0),
              "errors": res.get("errors", [])}

    if res["status"] != "OK" or not trades:
        report["verdict"] = "UNDETERMINED — REST did not answer; no substitute used"
        report["trades"] = 0
        _write(a.out, report, trades, None)
        print(json.dumps({k: report[k] for k in
                          ("status", "pages", "trades", "verdict")}, indent=2))
        return 2

    tot = sum(t["qty"] for t in trades)
    buy = sum(t["qty"] for t in trades if t["is_buyer_maker"] == 0)
    report.update({
        "trades": len(trades),
        "first_id": trades[0]["agg_id"], "last_id": trades[-1]["agg_id"],
        "first_ts": ms_to_iso(trades[0]["ts"]),
        "last_ts": ms_to_iso(trades[-1]["ts"]),
        "total_volume": round(tot, 6),
        "taker_buy_volume": round(buy, 6),
        "sell_volume": round(tot - buy, 6),
        "delta": round(buy - (tot - buy), 6),
        "raw_trade_count": sum(max(0, t["last_tid"] - t["first_tid"] + 1)
                               for t in trades),
        "gaps_in_ids": _id_gaps(trades),
    })

    day = a.start[:10]
    ref = klines_1m(a.symbol, day, start_ms, end_ms, a.out)
    if ref.get("status") == "ok" and ref.get("rows"):
        rv = sum(x["volume"] for x in ref["rows"])
        rt = sum(x["taker_buy"] for x in ref["rows"])
        rc = sum(x["count"] for x in ref["rows"])
        report["kline_1m"] = {
            "source": "data.binance.vision 1m klines (reference only)",
            "volume": round(rv, 6), "taker_buy": round(rt, 6),
            "count": rc,
            "volume_diff": round(tot - rv, 6),
            "volume_diff_pct": round(100 * (tot - rv) / rv, 6) if rv else None,
            "taker_buy_diff_pct": round(100 * (buy - rt) / rt, 6) if rt else None,
        }
        report["verdict"] = ("REST AGREES WITH KLINE" if abs(tot - rv) < 1e-6
                             else "REST DISAGREES WITH KLINE")
    else:
        report["kline_1m"] = ref
        report["verdict"] = "measured, no reference available"

    _write(a.out, report, trades, ref)
    print(json.dumps({k: report.get(k) for k in
                      ("status", "pages", "trades", "total_volume",
                       "taker_buy_volume", "verdict")}, indent=2))
    return 0


def _id_gaps(trades):
    g = 0
    for i in range(1, len(trades)):
        if trades[i]["agg_id"] != trades[i - 1]["agg_id"] + 1:
            g += 1
    return g


def _write(outdir, report, trades, ref):
    with open(os.path.join(outdir, "report.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    with open(os.path.join(outdir, "trades.csv"), "w", newline="",
              encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["agg_id", "ts_ms", "iso", "price", "qty", "is_buyer_maker"])
        for t in trades:
            w.writerow([t["agg_id"], t["ts"], t["iso"], t["price"], t["qty"],
                        t["is_buyer_maker"]])
    lines = ["# REST probe — %s" % report.get("window"),
             "", "- status: **%s**" % report.get("status"),
             "- pages: %s" % report.get("pages"),
             "- trades in window: %s" % report.get("trades"),
             "- total volume: %s" % report.get("total_volume"),
             "- taker buy: %s" % report.get("taker_buy_volume"),
             "- verdict: %s" % report.get("verdict"), ""]
    for e in report.get("errors", []):
        lines.append("- error page %s: %s" % (e.get("page"), e.get("error") or
                                              e.get("http_status")))
    with open(os.path.join(outdir, "report.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    raise SystemExit(main())

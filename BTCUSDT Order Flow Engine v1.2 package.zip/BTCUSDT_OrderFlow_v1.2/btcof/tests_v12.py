"""v1.2 test suite — the 15 mandatory areas turned into independent tests.

Every test runs against a throwaway SQLite file. No test is skipped to make the
suite look green: a behaviour that cannot be proven offline is reported as a
Skip by the caller, never turned into a Pass here.
"""
from __future__ import annotations

import os
import tempfile
import unittest
from datetime import date

from btcof import cvd, db, integrity as itg, schema
from btcof.integrity import (
    CVD_INCOMPLETE, CVD_UNKNOWN, CVD_VALID, GAP_UNRESOLVED,
    DownloadError, HttpStatusError,
)

SYM = "BTCUSDT"
T0 = int(schema.day_ms(date(2026, 10, 20)))
DAY = date(2026, 10, 20)


def trade(i: int, ts: int) -> dict:
    return {"agg_id": i, "ts": ts, "price": 100.0 + (i % 3), "qty": 1.0,
            "first_tid": i, "last_tid": i, "is_buyer_maker": 0}


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="btcof12_")
        self.conn = db.connect(os.path.join(self.tmp, "test.db"))

    def tearDown(self):
        try:
            self.conn.close()
        except Exception:
            pass

    def seed(self, ids, ts=T0 + 1000, day=DAY, complete_day=True):
        itg._insert_trades(self.conn, SYM, [trade(i, ts) for i in ids])
        self.conn.commit()
        if complete_day:
            itg._log_additive(self.conn, "archive:%s:%s" % (SYM, day.isoformat()),
                              SYM, len(ids), 0, 0, "unit=ms rows=%d" % len(ids))


class TestCvdValidity(Base):
    # 1
    def test_late_insert_invalidates_checkpoint(self):
        self.seed(list(range(1, 4)))
        db.save_checkpoint(self.conn, SYM, 30, itg.bar_open_ms(T0 + 1000), 5.0, 3,
                           T0 + 1000, cvd_open=0.0)
        self.conn.commit()
        self.assertIsNotNone(db.load_checkpoint(self.conn, SYM, 30))
        res = itg.register_late_rows(self.conn, SYM, [trade(9, T0 + 500)])
        self.assertGreaterEqual(res["invalidated"], 1)
        self.assertIsNone(db.load_checkpoint(self.conn, SYM, 30))

    # 2
    def test_checkpoint_invalidation_boundary(self):
        step = 30 * 60_000
        self.seed([1], T0 + 1000)
        cp_bar = itg.bar_open_ms(T0 + 2 * step)
        db.save_checkpoint(self.conn, SYM, 30, cp_bar, 1.0, 1, T0 + 1000, cvd_open=0.0)
        self.conn.commit()
        # a row far in the future must NOT void the checkpoint
        itg.register_late_rows(self.conn, SYM, [trade(2, T0 + 6 * step)])
        self.assertIsNotNone(db.load_checkpoint(self.conn, SYM, 30))
        # a row inside an already-counted bar must void it
        itg.register_late_rows(self.conn, SYM, [trade(3, T0 + 500)])
        self.assertIsNone(db.load_checkpoint(self.conn, SYM, 30))

    # 3
    def test_cvd_valid_when_clean(self):
        self.seed(list(range(1, 51)))
        st = itg.cvd_status(self.conn, SYM, 30)
        self.assertEqual(st["status"], CVD_VALID, st["reasons"])

    # 4
    def test_cvd_incomplete_on_id_gap(self):
        self.seed([1, 2, 5, 6])
        st = itg.cvd_status(self.conn, SYM, 30)
        self.assertEqual(st["status"], CVD_INCOMPLETE, st["reasons"])
        self.assertTrue(any("aggTrade id gaps" in r for r in st["reasons"]))

    # 5
    def test_cvd_unknown_on_missing_file(self):
        self.seed([1, 2, 3])
        itg._log_additive(self.conn, "archive:%s:2026-10-21" % SYM, SYM, 0, 0, 0,
                          "FILE NOT PUBLISHED")
        st = itg.cvd_status(self.conn, SYM, 30, start=date(2026, 10, 20),
                            end=date(2026, 10, 21))
        self.assertEqual(st["status"], CVD_UNKNOWN, st["reasons"])

    # 6
    def test_unresolved_gap_never_valid(self):
        self.seed(list(range(1, 21)))
        db.set_state(self.conn, "gap:%s" % SYM, "hole at agg_id=9")
        self.conn.commit()
        st = itg.cvd_status(self.conn, SYM, 30)
        self.assertNotEqual(st["status"], CVD_VALID)

    # 7
    def test_rebuild_equals_continue_after_backfill(self):
        self.seed(list(range(1, 21)), ts=T0 + 1000)
        first = cvd.rebuild(self.conn, SYM, 30)
        cont = cvd.continue_(self.conn, SYM, 30)
        self.assertAlmostEqual(first["cvd"], cont["cvd"], places=9)
        self.assertIsNotNone(db.load_checkpoint(self.conn, SYM, 30))

        late = [trade(100 + i, T0 + 2000 + i) for i in range(5)]
        itg._insert_trades(self.conn, SYM, late)
        self.conn.commit()
        itg.register_late_rows(self.conn, SYM, late)
        self.assertIsNone(db.load_checkpoint(self.conn, SYM, 30),
                          "backfill must void the checkpoint")

        after = cvd.rebuild(self.conn, SYM, 30)
        cont2 = cvd.continue_(self.conn, SYM, 30)
        self.assertAlmostEqual(after["cvd"], cont2["cvd"], places=9)
        self.assertNotAlmostEqual(first["cvd"], after["cvd"], places=9)


class TestGapClasses(Base):
    # 8
    def test_missing_file_is_not_ok(self):
        itg._log_additive(self.conn, "archive:%s:%s" % (SYM, DAY.isoformat()), SYM,
                          0, 0, 0, "FILE NOT PUBLISHED")
        d = itg.classify_day(self.conn, SYM, DAY)
        self.assertEqual(d["status"], "missing_file")
        self.assertFalse(d["ok"])

    # 9
    def test_empty_file_is_not_ok(self):
        itg._log_additive(self.conn, "archive:%s:%s" % (SYM, DAY.isoformat()), SYM,
                          0, 0, 0, "EMPTY FILE")
        d = itg.classify_day(self.conn, SYM, DAY)
        self.assertEqual(d["status"], "empty_file")
        self.assertFalse(d["ok"])

    # 10
    def test_partial_day_is_not_ok(self):
        step = 30 * 60_000
        itg._insert_trades(self.conn, SYM, [trade(1, T0 + 10), trade(2, T0 + 3 * step)])
        self.conn.commit()
        itg._log_additive(self.conn, "archive:%s:%s" % (SYM, DAY.isoformat()), SYM,
                          2, 0, 0, "unit=ms rows=2")
        cov = itg.day_bucket_coverage(self.conn, SYM, DAY)
        self.assertEqual(cov["missing_buckets"], 2)
        d = itg.classify_day(self.conn, SYM, DAY)
        self.assertEqual(d["status"], "partial")
        self.assertFalse(d["ok"])

    # 11
    def test_unknown_day_not_folded_into_complete(self):
        self.seed([1, 2, 3])
        st = itg.archive_status(self.conn, SYM, date(2026, 10, 20), date(2026, 10, 22))
        self.assertFalse(st["all_ok"])
        self.assertIn("2026-10-20", st["complete"])
        self.assertIn("2026-10-21", st["unknown"])

    # 12
    def test_three_gap_classes_independent(self):
        step = 30 * 60_000
        itg._insert_trades(self.conn, SYM, [trade(1, T0 + 10), trade(3, T0 + 2 * step)])
        self.conn.commit()
        itg._log_additive(self.conn, "archive:%s:%s" % (SYM, DAY.isoformat()), SYM,
                          2, 0, 0, "unit=ms rows=2")
        itg._log_additive(self.conn, "archive:%s:2026-10-21" % SYM, SYM, 0, 0, 0,
                          "FILE NOT PUBLISHED")
        st = itg.archive_status(self.conn, SYM, date(2026, 10, 20), date(2026, 10, 21))
        cont = itg.gaps.continuity(self.conn, SYM, 30)
        self.assertEqual(len(st["missing_files"]), 1)          # A
        self.assertEqual(cont["id_gap_events"], 1)             # B
        self.assertGreater(cont["empty_buckets"], 0)           # C
        self.assertIn("2026-10-20", st["partial"])
        self.assertIn("2026-10-21", st["missing_files"])


class TestDownloaderResume(Base):
    def _zip(self, size=16):
        p = os.path.join(self.tmp, "a.zip")
        with open(p, "wb") as f:
            f.write(b"PK" + b"0" * size)
        return p

    def _reader(self, rows=None, fail=None):
        class R:
            def __init__(self, path):
                self.rows = rows or []
                self.fail = fail

            def __iter__(self):
                for r in self.rows:
                    yield r
                if self.fail is not None:
                    raise self.fail
        return lambda p: R(p)

    # 13
    def test_resume_skips_completed_day(self):
        p = self._zip()
        f = lambda s, d: {"path": p}
        r = self._reader([trade(1, T0), trade(2, T0 + 1)])
        a = itg.safe_ingest_day(self.conn, SYM, DAY, fetch=f, reader_factory=r)
        self.assertEqual(a["status"], "ok")
        b = itg.safe_ingest_day(self.conn, SYM, DAY, fetch=f, reader_factory=r)
        self.assertEqual(b["status"], "skip")
        n = self.conn.execute("SELECT COUNT(*) c FROM agg_trades").fetchone()["c"]
        self.assertEqual(n, 2)

    # 14
    def test_resume_retries_interrupted_day(self):
        def bad(s, d):
            raise DownloadError("incomplete", "content-length mismatch")
        a = itg.safe_ingest_day(self.conn, SYM, DAY, fetch=bad,
                                reader_factory=self._reader([]))
        self.assertEqual(a["status"], "retryable")
        self.assertFalse(itg.day_complete(self.conn, SYM, DAY))
        p = self._zip()
        b = itg.safe_ingest_day(self.conn, SYM, DAY, fetch=lambda s, d: {"path": p},
                                reader_factory=self._reader([trade(1, T0)]))
        self.assertEqual(b["status"], "ok")
        self.assertTrue(itg.day_complete(self.conn, SYM, DAY))

    # 15
    def test_empty_download_is_not_success(self):
        p = os.path.join(self.tmp, "empty.zip")
        open(p, "wb").close()
        r = itg.safe_ingest_day(self.conn, SYM, DAY, fetch=lambda s, d: {"path": p},
                                reader_factory=self._reader([trade(1, T0)]))
        self.assertEqual(r["status"], "empty_file")
        self.assertFalse(itg.day_complete(self.conn, SYM, DAY))

    # 16
    def test_corrupt_archive_is_retryable(self):
        p = self._zip()
        bad = self._reader(fail=schema.SchemaError("bad header"))
        r = itg.safe_ingest_day(self.conn, SYM, DAY, fetch=lambda s, d: {"path": p},
                                reader_factory=bad)
        self.assertEqual(r["status"], "schema_error")
        self.assertFalse(itg.day_complete(self.conn, SYM, DAY))
        good = self._reader([trade(1, T0)])
        r2 = itg.safe_ingest_day(self.conn, SYM, DAY, fetch=lambda s, d: {"path": p},
                                 reader_factory=good)
        self.assertEqual(r2["status"], "ok")

    # 17
    def test_rerun_does_not_wipe_previous_stats(self):
        p = self._zip()
        f = lambda s, d: {"path": p}
        rows = [trade(1, T0), trade(2, T0 + 1)]
        itg.safe_ingest_day(self.conn, SYM, DAY, fetch=f,
                            reader_factory=self._reader(rows))
        itg.safe_ingest_day(self.conn, SYM, DAY, fetch=f,
                            reader_factory=self._reader(rows), force=True)
        log = self.conn.execute(
            "SELECT rows FROM ingest_log WHERE source=?",
            ("archive:%s:%s" % (SYM, DAY.isoformat()),)).fetchone()
        self.assertEqual(log["rows"], 2)
        n = self.conn.execute("SELECT COUNT(*) c FROM agg_trades").fetchone()["c"]
        self.assertEqual(n, 2)

    # 18
    def test_failed_ingest_writes_nothing(self):
        p = self._zip()
        bad = self._reader([trade(1, T0), trade(2, T0 + 1)],
                           fail=schema.SchemaError("truncated row"))
        itg.safe_ingest_day(self.conn, SYM, DAY, fetch=lambda s, d: {"path": p},
                            reader_factory=bad)
        n = self.conn.execute("SELECT COUNT(*) c FROM agg_trades").fetchone()["c"]
        self.assertEqual(n, 0, "a failed import must roll back completely")


class TestRestAndWs(Base):
    # 19
    def test_rest_gap_stops_ingest(self):
        rows = [trade(3, T0), trade(4, T0 + 1), trade(7, T0 + 2), trade(8, T0 + 3)]
        r = itg.rest_backfill(self.conn, SYM, rows, next_id=3)
        self.assertEqual(r["status"], GAP_UNRESOLVED)
        self.assertEqual(r["accepted"], 2)
        self.assertEqual(r["hole_at"], 5)
        stored = [x["agg_id"] for x in self.conn.execute(
            "SELECT agg_id FROM agg_trades ORDER BY agg_id")]
        self.assertEqual(stored, [3, 4])

    # 20
    def test_rest_contiguous_prefix_only(self):
        rows = [trade(2, T0), trade(3, T0 + 1), trade(4, T0 + 2)]
        acc, nxt = itg.contiguous_prefix(rows, 3)
        self.assertEqual([x["agg_id"] for x in acc], [3, 4])
        self.assertEqual(nxt, 5)
        r = itg.rest_backfill(self.conn, SYM, rows, next_id=3)
        self.assertEqual(r["status"], "OK")

    # 21
    def test_rest_unavailable_means_unresolved(self):
        r = itg.ws_recovery(delivered_last_id=12, rest_ids=[])
        self.assertEqual(r["status"], GAP_UNRESOLVED)

    # 22
    def test_ws_101_alone_is_not_success(self):
        self.assertFalse(itg.ws_delivery_ok(101, None))
        self.assertTrue(itg.ws_delivery_ok(101, {"e": "aggTrade"}))
        self.assertFalse(itg.ws_delivery_ok(200, {"e": "aggTrade"}))

    # 23
    def test_ws_reconnect_recovers(self):
        self.assertEqual(itg.ws_recovery(12, [13, 14])["status"], "OK")
        self.assertEqual(itg.ws_recovery(12, [20, 21])["status"], GAP_UNRESOLVED)
        self.assertEqual(itg.reconnect_delays(4), [1.0, 2.0, 4.0, 8.0])


class TestHttpPaginationKline(Base):
    # 24
    def test_http_errors_are_errors(self):
        for code in (403, 418, 429, 451):
            with self.assertRaises(HttpStatusError):
                itg.http_ok(code, None)

    # 25
    def test_empty_body_is_error(self):
        with self.assertRaises(HttpStatusError):
            itg.http_ok(200, "")
        with self.assertRaises(HttpStatusError):
            itg.http_ok(200, [])

    # 26
    def test_pagination_verdict(self):
        self.assertEqual(itg.pagination_verdict(False, 100, 100), "INCOMPLETE")
        self.assertEqual(itg.pagination_verdict(True, 100, 60), "INCOMPLETE")
        self.assertEqual(itg.pagination_verdict(True, 100, 100), "OK")
        self.assertEqual(itg.pagination_verdict(True, None, 10), "UNDETERMINED")

    # 27
    def test_kline_ok_requires_clean(self):
        opens = [T0, T0 + 1]
        self.assertEqual(itg.validate_kline(opens, {T0: (1.0, 1.0), T0 + 1: (1.0, 1.0)})["status"], "OK")
        self.assertEqual(itg.validate_kline(opens, {T0: (1.0, 1.0)}, invalid_rows=1)["status"], "INCOMPLETE")
        self.assertEqual(itg.validate_kline(None, {})["status"], "UNDETERMINED")

    # 28
    def test_kline_zero_reference(self):
        res = itg.validate_kline([T0], {T0: (0.0, 0.0)})
        self.assertEqual(res["differing"], 0)
        self.assertEqual(res["status"], "OK")

    # 29
    def test_kline_counts_are_separate(self):
        res = itg.validate_kline([T0, T0 + 1, T0 + 2],
                                 {T0: (1.0, 1.0), T0 + 1: (2.0, 3.0)})
        self.assertEqual(res["expected"], 3)
        self.assertEqual(res["missing"], 1)
        self.assertEqual(res["differing"], 1)

    # 30
    def test_m30_utc_boundaries(self):
        base = 1792454400000  # 2026-10-20 00:00:00 UTC
        self.assertEqual(itg.bar_open_ms(base, 30), base)
        self.assertEqual(itg.bar_open_ms(base + 30 * 60_000 - 1, 30), base)
        self.assertEqual(itg.bar_open_ms(base + 30 * 60_000, 30), base + 30 * 60_000)
        self.assertEqual(schema.utc_day(base + 86_399_999), date(2026, 10, 20))

    # 31
    def test_report_counts_limited_to_window(self):
        itg._insert_trades(self.conn, SYM, [trade(1, T0), trade(2, T0 + 1),
                                            trade(3, T0 + 2)])
        itg._insert_trades(self.conn, SYM, [trade(4, T0 + 86_400_000)])
        self.conn.commit()
        self.assertEqual(itg.range_rows(self.conn, SYM, T0, T0 + 86_400_000), 3)
        self.assertEqual(itg.range_rows(self.conn, SYM, T0, T0 + 2), 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
"""v1.2 integrity layer.

Pure data-integrity logic on top of btcof.db:
  * CVD validity states and checkpoint invalidation after late/backfilled rows
  * three independent gap classes (missing archive file, aggTrade id, time)
  * REST backfill continuity guard (never steps over a hole)
  * resumable, transactional archive ingestion that never reports partial as done
  * HTTP / pagination / kline verdicts that never turn an error into empty data

No strategy, no signals, no risk logic.
"""
from __future__ import annotations

import os
from typing import Callable, Dict, Iterable, List, Optional, Sequence

from . import db, gaps, schema, sources

CVD_VALID = "CVD_VALID"
CVD_INCOMPLETE = "CVD_INCOMPLETE"
CVD_UNKNOWN = "CVD_UNKNOWN"
GAP_UNRESOLVED = "GAP_UNRESOLVED"

RETRYABLE_PREFIXES = (
    "FILE NOT PUBLISHED",
    "SCHEMA ERROR",
    "EMPTY FILE",
    "PARTIAL",
    "DOWNLOAD INCOMPLETE",
    "DOWNLOAD FAILED",
)


class DownloadError(RuntimeError):
    """A transfer that did not produce a usable file."""

    def __init__(self, code: str, detail: str = ""):
        self.code = code
        self.detail = detail
        super().__init__("%s: %s" % (code, detail))


class HttpStatusError(RuntimeError):
    """A non-2xx HTTP answer. Never converted into an empty result."""

    RETRY_AFTER = (403, 418, 429, 451)

    def __init__(self, status: int, detail: str = ""):
        self.status = status
        self.detail = detail
        super().__init__("HTTP %s%s" % (status, (": %s" % detail) if detail else ""))


# --------------------------------------------------------------------------
# bars / helpers
# --------------------------------------------------------------------------

def bar_open_ms(ts_ms: int, tf_minutes: int = 30) -> int:
    step = tf_minutes * 60_000
    return int(ts_ms - (ts_ms % step))


def _id_of(row) -> int:
    if isinstance(row, dict):
        return int(row["agg_id"])
    if hasattr(row, "agg_id"):
        return int(row.agg_id)
    return int(row[0])


def _ts_of(row) -> int:
    if isinstance(row, dict):
        return int(row["ts"])
    if hasattr(row, "ts"):
        return int(row.ts)
    return int(row[1])


def _norm(row) -> Dict:
    if isinstance(row, dict):
        return dict(row)
    if hasattr(row, "agg_id"):
        return {"agg_id": int(row.agg_id), "ts": int(row.ts),
                "price": float(row.price), "qty": float(row.qty),
                "first_tid": int(getattr(row, "first_tid", row.agg_id)),
                "last_tid": int(getattr(row, "last_tid", row.agg_id)),
                "is_buyer_maker": int(getattr(row, "is_buyer_maker", 0))}
    r = list(row)
    return {"agg_id": int(r[0]), "ts": int(r[1]), "price": float(r[2]),
            "qty": float(r[3]), "first_tid": int(r[4]), "last_tid": int(r[5]),
            "is_buyer_maker": int(r[6])}


def _insert_trades(conn, symbol: str, rows: Sequence) -> int:
    """Insert normalised rows; a duplicate agg_id is ignored, never overwritten."""
    inserted = 0
    for raw in rows:
        r = _norm(raw)
        cur = conn.execute(
            "INSERT OR IGNORE INTO agg_trades "
            "(symbol, agg_id, ts, price, qty, first_tid, last_tid, is_buyer_maker) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (symbol, r["agg_id"], r["ts"], r["price"], r["qty"],
             r["first_tid"], r["last_tid"], r["is_buyer_maker"]))
        inserted += cur.rowcount
    return inserted


# --------------------------------------------------------------------------
# CVD checkpoints
# --------------------------------------------------------------------------

def invalidate_checkpoints(conn, symbol: str, from_ts_ms: Optional[int] = None,
                           tf_minutes: int = 30) -> int:
    """Drop every checkpoint whose bar can be affected by a row at/after from_ts_ms.

    from_ts_ms=None drops all checkpoints of the symbol (full rebuild required).
    """
    if from_ts_ms is None:
        cur = conn.execute("DELETE FROM cvd_checkpoints WHERE symbol=?", (symbol,))
    else:
        cutoff = bar_open_ms(int(from_ts_ms), tf_minutes)
        cur = conn.execute(
            "DELETE FROM cvd_checkpoints WHERE symbol=? AND bar_open_time>=?",
            (symbol, cutoff))
    conn.commit()
    return cur.rowcount


def register_late_rows(conn, symbol: str, rows: Sequence,
                       tf_minutes: int = 30) -> Dict:
    """Rows that arrive late (backfill / redelivery) must void the checkpoints."""
    if not rows:
        return {"invalidated": 0, "from_ts": None}
    from_ts = min(_ts_of(r) for r in rows)
    n = invalidate_checkpoints(conn, symbol, from_ts, tf_minutes)
    return {"invalidated": n, "from_ts": from_ts,
            "cutoff": bar_open_ms(from_ts, tf_minutes)}


# --------------------------------------------------------------------------
# day classification (three independent gap classes)
# --------------------------------------------------------------------------

def _log_row(conn, tag: str):
    return conn.execute("SELECT detail, rows FROM ingest_log WHERE source=?",
                        (tag,)).fetchone()


def classify_day(conn, symbol: str, d, tf_minutes: int = 30) -> Dict:
    """Classify one UTC day. `ok` is True only for a complete, loaded day."""
    tag = "archive:%s:%s" % (symbol, d.isoformat())
    log = _log_row(conn, tag)
    detail = (log["detail"] if log is not None else "") or ""

    d0 = int(schema.day_ms(d))
    d1 = d0 + 86_400_000
    rows = conn.execute(
        "SELECT COUNT(*) c FROM agg_trades WHERE symbol=? AND ts>=? AND ts<?",
        (symbol, d0, d1)).fetchone()["c"]

    if detail.startswith("FILE NOT PUBLISHED"):
        status = "missing_file"
    elif detail.startswith("EMPTY FILE"):
        status = "empty_file"
    elif detail.startswith("SCHEMA ERROR"):
        status = "corrupt_file"
    elif detail.startswith("PARTIAL") or detail.startswith("DOWNLOAD"):
        status = "truncated"
    elif rows == 0:
        status = "unknown"
    elif "PARTIAL" in detail:
        status = "truncated"
    else:
        status = "ok"

    # a loaded day whose M30 buckets are not all present is partial, not ok
    if status == "ok":
        cov = day_bucket_coverage(conn, symbol, d, tf_minutes)
        if cov["missing_buckets"] > 0:
            status = "partial"

    return {"day": d.isoformat(), "status": status, "rows": rows,
            "detail": detail, "ok": status == "ok"}


def day_bucket_coverage(conn, symbol: str, d, tf_minutes: int = 30) -> Dict:
    step = tf_minutes * 60_000
    d0 = int(schema.day_ms(d))
    rows = conn.execute(
        "SELECT DISTINCT (ts - (ts % ?)) b FROM agg_trades "
        "WHERE symbol=? AND ts>=? AND ts<?", (step, symbol, d0, d0 + 86_400_000)
    ).fetchall()
    present = set(int(r["b"]) for r in rows)
    if not present:
        return {"present_buckets": 0, "missing_buckets": 0, "first": None, "last": None}
    lo, hi = min(present), max(present)
    expected = (hi - lo) // step + 1
    return {"present_buckets": len(present),
            "missing_buckets": int(expected - len(present)),
            "first": lo, "last": hi}


def archive_status(conn, symbol: str, start, end, tf_minutes: int = 30) -> Dict:
    """Roll a day range up. Unknown is never folded into complete."""
    from datetime import timedelta
    days = []
    d = start
    while d <= end:
        days.append(classify_day(conn, symbol, d, tf_minutes))
        d += timedelta(days=1)
    bucket = {}
    for x in days:
        bucket.setdefault(x["status"], []).append(x["day"])
    return {"days": days,
            "by_status": bucket,
            "missing_files": bucket.get("missing_file", []),
            "empty_files": bucket.get("empty_file", []),
            "corrupt_files": bucket.get("corrupt_file", []),
            "truncated": bucket.get("truncated", []),
            "partial": bucket.get("partial", []),
            "unknown": bucket.get("unknown", []),
            "complete": bucket.get("ok", []),
            "all_ok": len(days) > 0 and all(x["ok"] for x in days)}


# --------------------------------------------------------------------------
# CVD status
# --------------------------------------------------------------------------

def cvd_status(conn, symbol: str, tf_minutes: int = 30,
               start=None, end=None) -> Dict:
    """CVD is VALID only when the tape is loaded, contiguous and gap-free."""
    span = conn.execute("SELECT MIN(ts) a, MAX(ts) b, COUNT(*) n FROM agg_trades "
                        "WHERE symbol=?", (symbol,)).fetchone()
    if not span["n"]:
        return {"status": CVD_UNKNOWN, "reasons": ["no data stored"]}

    reasons: List[str] = []
    a, b = int(span["a"]), int(span["b"])
    s = start if start is not None else schema.utc_day(a)
    e = end if end is not None else schema.utc_day(b)
    cov = archive_status(conn, symbol, s, e, tf_minutes)

    unknown_days = cov["missing_files"] + cov["empty_files"] + cov["unknown"]
    if unknown_days:
        reasons.append("archive coverage unknown/missing for %d day(s)" % len(unknown_days))
    if cov["corrupt_files"] or cov["truncated"] or cov["partial"]:
        reasons.append("archive day(s) corrupt/truncated/partial: %d"
                       % (len(cov["corrupt_files"]) + len(cov["truncated"]) + len(cov["partial"])))

    cont = gaps.continuity(conn, symbol, tf_minutes)
    if cont.get("id_gap_events"):
        reasons.append("aggTrade id gaps: %d (missing %d)"
                       % (cont["id_gap_events"], cont.get("id_missing_total", 0)))
    if cont.get("empty_buckets"):
        reasons.append("empty %d-min buckets: %d" % (tf_minutes, cont["empty_buckets"]))

    conflicts = conn.execute(
        "SELECT COALESCE(SUM(conflicts),0) c FROM ingest_log WHERE symbol=?",
        (symbol,)).fetchone()["c"]
    if conflicts:
        reasons.append("conflicting duplicates: %d" % conflicts)

    unresolved = db.get_state(conn, "gap:%s" % symbol)
    if unresolved:
        reasons.append("unresolved REST/WS gap recorded: %s" % unresolved)

    cp = db.load_checkpoint(conn, symbol, tf_minutes)
    if cp is not None:
        row = conn.execute("SELECT ts FROM agg_trades WHERE symbol=? AND agg_id=?",
                           (symbol, cp["last_agg_id"])).fetchone()
        if row is None or row["ts"] != cp["last_ts"]:
            reasons.append("checkpoint no longer matches the tape")

    if reasons and (unknown_days or unresolved):
        return {"status": CVD_UNKNOWN, "reasons": reasons,
                "coverage": cov["by_status"]}
    if reasons:
        return {"status": CVD_INCOMPLETE, "reasons": reasons,
                "coverage": cov["by_status"]}
    return {"status": CVD_VALID, "reasons": [], "coverage": cov["by_status"]}


# --------------------------------------------------------------------------
# REST backfill continuity guard
# --------------------------------------------------------------------------

def contiguous_prefix(rows: Sequence, next_id: int) -> tuple:
    """Keep only the unbroken run starting exactly at next_id."""
    accepted: List = []
    nxt = int(next_id)
    for r in rows:
        i = _id_of(r)
        if i < nxt:
            continue              # duplicate / already stored
        if i == nxt:
            accepted.append(r)
            nxt += 1
        else:
            break                 # a hole: stop, never step over it
    return accepted, nxt


def rest_backfill(conn, symbol: str, rows: Sequence, next_id: int,
                  tf_minutes: int = 30) -> Dict:
    """Insert only the contiguous prefix of a REST page.

    A hole in the answer is recorded as GAP_UNRESOLVED; nothing behind the hole
    is written, and affected checkpoints are invalidated.
    """
    accepted, nxt = contiguous_prefix(rows, next_id)
    ids = [_id_of(r) for r in rows]
    hole_at = None
    if ids and max(ids) >= nxt:
        hole_at = nxt
    elif accepted and len(accepted) < len([i for i in ids if i >= next_id]):
        hole_at = nxt

    inserted = 0
    try:
        conn.execute("BEGIN IMMEDIATE")
        if accepted:
            inserted = _insert_trades(conn, symbol, accepted)
        conn.commit()
    except Exception:
        conn.rollback()
        raise

    if accepted:
        register_late_rows(conn, symbol, accepted, tf_minutes)

    status = "OK" if hole_at is None else GAP_UNRESOLVED
    if hole_at is not None:
        db.set_state(conn, "gap:%s" % symbol, "hole at agg_id=%s" % hole_at)
        conn.commit()
    else:
        db.set_state(conn, "gap:%s" % symbol, "")
        conn.commit()

    return {"status": status, "accepted": len(accepted), "inserted": inserted,
            "hole_at": hole_at, "next_id": nxt}


# --------------------------------------------------------------------------
# WebSocket recovery
# --------------------------------------------------------------------------

def ws_delivery_ok(handshake_status: int, payload) -> bool:
    """HTTP 101 alone is not data: a parsed aggTrade must have arrived."""
    return int(handshake_status) == 101 and payload is not None


def ws_recovery(delivered_last_id: int, rest_ids: Sequence[int]) -> Dict:
    """Can the socket resume without a hole? The answer must come from REST."""
    rest = sorted(int(i) for i in rest_ids)
    want = int(delivered_last_id) + 1
    if not rest:
        return {"status": GAP_UNRESOLVED, "resume_from": want,
                "detail": "REST unavailable, cannot prove continuity"}
    if rest[0] > want:
        return {"status": GAP_UNRESOLVED, "resume_from": want,
                "hole_at": want, "detail": "REST starts after the socket tail"}
    return {"status": "OK", "resume_from": max(rest) + 1, "reconnect": True,
            "detail": "continuity proven by REST"}


def reconnect_delays(attempts: int, base: float = 1.0, cap: float = 30.0) -> List[float]:
    out = []
    for i in range(max(0, attempts)):
        out.append(min(cap, base * (2 ** i)))
    return out


# --------------------------------------------------------------------------
# resumable, transactional archive ingestion
# --------------------------------------------------------------------------

def _is_retryable(detail: Optional[str]) -> bool:
    if not detail:
        return False
    return any(detail.upper().startswith(p) for p in RETRYABLE_PREFIXES)


def _log_additive(conn, tag: str, symbol: str, rows: int, dupes: int,
                  conflicts: int, detail: str) -> None:
    conn.execute(
        "INSERT INTO ingest_log (source, symbol, kind, rows, dupes, conflicts, detail) "
        "VALUES (?,?,?,?,?,?,?) "
        "ON CONFLICT(source) DO UPDATE SET "
        "  rows=COALESCE(ingest_log.rows,0)+excluded.rows, "
        "  dupes=COALESCE(ingest_log.dupes,0)+excluded.dupes, "
        "  conflicts=COALESCE(ingest_log.conflicts,0)+excluded.conflicts, "
        "  detail=excluded.detail",
        (tag, symbol, "archive", rows, dupes, conflicts, detail))
    conn.commit()


def day_complete(conn, symbol: str, d) -> bool:
    log = _log_row(conn, "archive:%s:%s" % (symbol, d.isoformat()))
    if log is None:
        return False
    return not _is_retryable((log["detail"] or ""))


def safe_ingest_day(conn, symbol: str, d, fetch: Optional[Callable] = None,
                    reader_factory: Optional[Callable] = None,
                    force: bool = False, tf_minutes: int = 30) -> Dict:
    """Ingest one archive day with real resume semantics.

    * a completed day is skipped (resume)
    * missing / schema_error / empty / truncated days are retried
    * rows land in one transaction: a failure writes nothing
    * an empty or truncated transfer is never recorded as success
    """
    tag = "archive:%s:%s" % (symbol, d.isoformat())
    log = _log_row(conn, tag)
    if log is not None and not force and not _is_retryable(log["detail"]):
        return {"source": tag, "status": "skip"}

    if fetch is None:
        return {"source": tag, "status": "no_fetcher"}

    try:
        res = fetch(symbol, d)
    except DownloadError as e:
        _log_additive(conn, tag, symbol, 0, 0, 0, "DOWNLOAD %s: %s" % (e.code.upper(), e.detail))
        return {"source": tag, "status": "retryable", "detail": e.code}

    if not res or not res.get("path"):
        _log_additive(conn, tag, symbol, 0, 0, 0, "FILE NOT PUBLISHED")
        return {"source": tag, "status": "missing"}

    path = res["path"]
    size = os.path.getsize(path) if os.path.exists(path) else 0
    if size == 0:
        _log_additive(conn, tag, symbol, 0, 0, 0, "EMPTY FILE")
        return {"source": tag, "status": "empty_file"}

    factory = reader_factory or (lambda p: sources.AggArchiveFile(p))
    inserted = dupes = conflicts = 0
    seen = 0
    try:
        reader = factory(path)
        batch: List = []
        conn.execute("BEGIN IMMEDIATE")
        for row in reader:
            seen += 1
            batch.append(row)
            if len(batch) >= 5000:
                inserted += _insert_trades(conn, symbol, batch)
                batch = []
        if batch:
            inserted += _insert_trades(conn, symbol, batch)
        conn.commit()
    except schema.SchemaError as e:
        conn.rollback()
        _log_additive(conn, tag, symbol, 0, 0, 0, "SCHEMA ERROR: %s" % e)
        return {"source": tag, "status": "schema_error", "detail": str(e)}
    except DownloadError as e:
        conn.rollback()
        _log_additive(conn, tag, symbol, 0, 0, 0, "PARTIAL: %s" % e.code)
        return {"source": tag, "status": "truncated", "detail": e.code}
    except Exception as e:  # noqa: BLE001 - a broken archive must not kill the run
        conn.rollback()
        _log_additive(conn, tag, symbol, 0, 0, 0, "SCHEMA ERROR: %s" % e)
        return {"source": tag, "status": "schema_error", "detail": str(e)}

    if seen == 0:
        _log_additive(conn, tag, symbol, 0, 0, 0, "EMPTY FILE")
        return {"source": tag, "status": "empty_file"}

    _log_additive(conn, tag, symbol, inserted, dupes, conflicts,
                  "unit=ms rows=%d" % inserted)
    return {"source": tag, "status": "ok", "rows": inserted}


# --------------------------------------------------------------------------
# HTTP / pagination / kline verdicts
# --------------------------------------------------------------------------

def http_ok(status: int, body) -> Dict:
    """Any 4xx/5xx is an error, never an empty result."""
    status = int(status)
    if status in HttpStatusError.RETRY_AFTER or status >= 500:
        raise HttpStatusError(status, "blocked" if status == 451 else "")
    if status < 200 or status >= 300:
        raise HttpStatusError(status)
    if body is None or body == "" or body == [] or body == {}:
        raise HttpStatusError(status, "empty body")
    return {"status": "ok", "body": body}


def pagination_verdict(complete: bool, expected: Optional[int],
                       got: Optional[int]) -> str:
    if expected is None or got is None:
        return "UNDETERMINED"
    if not complete or got < expected:
        return "INCOMPLETE"
    return "OK"


def validate_kline(expected_opens: Optional[Sequence[int]],
                   actual: Dict[int, float],
                   invalid_rows: int = 0,
                   tolerance: float = 0.0) -> Dict:
    """Compare stored M30 closes with the reference series.

    status is OK only when the expected range is known, every bar is present,
    values match, and no invalid row was seen.
    """
    if expected_opens is None:
        return {"status": "UNDETERMINED", "reason": "reference window unknown",
                "expected": 0, "missing": 0, "differing": 0,
                "invalid_rows": int(invalid_rows)}
    exp = [int(x) for x in expected_opens]
    missing = [o for o in exp if o not in actual]
    differing = []
    for o in exp:
        if o not in actual:
            continue
        ref, got = actual[o]
        if ref is None or got is None:
            differing.append(o)
        elif float(ref) == 0.0 and float(got) == 0.0:
            continue                      # zero reference matches zero
        elif abs(float(got) - float(ref)) > tolerance:
            differing.append(o)

    status = "OK"
    if int(invalid_rows) > 0 or missing or differing:
        status = "INCOMPLETE"
    return {"status": status, "expected": len(exp), "missing": len(missing),
            "differing": len(differing), "invalid_rows": int(invalid_rows),
            "missing_examples": missing[:5], "differing_examples": differing[:5]}


def range_rows(conn, symbol: str, start_ms: int, end_ms: int) -> int:
    """Every report count is limited to the requested window."""
    return conn.execute(
        "SELECT COUNT(*) c FROM agg_trades WHERE symbol=? AND ts>=? AND ts<?",
        (symbol, int(start_ms), int(end_ms))).fetchone()["c"]
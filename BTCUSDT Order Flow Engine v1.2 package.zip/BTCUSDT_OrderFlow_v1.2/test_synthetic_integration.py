"""Synthetic integration checks against v1.2 production code, no network.
Run: python -m unittest -v test_synthetic_integration
"""
import tempfile
import unittest
from unittest.mock import patch

from btcof import cvd, db, downloader, gaps, schema, sources

SYMBOL = 'BTCUSDT'
# Exactly at an M30 UTC boundary.
BASE = 1_704_067_200_000


def trade(agg_id, seconds, qty, maker, first_tid, last_tid=None):
    return {'a': agg_id, 'p': '40000.0', 'q': str(qty),
            'f': first_tid, 'l': first_tid if last_tid is None else last_tid,
            'T': BASE + seconds * 1000, 'm': maker}


class Response:
    status_code = 200
    headers = {}
    text = ''

    def __init__(self, data):
        self.data = data

    def json(self):
        return self.data


class IntegrationTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.conn = db.connect(self.temp.name + '/integration.sqlite')

    def tearDown(self):
        self.conn.close()
        self.temp.cleanup()

    def rest_rows(self, payload):
        # Mock only transport; real RestClient parses the JSON using row_from_rest.
        with patch('requests.sessions.Session.get', return_value=Response(payload)), \
             patch('btcof.sources.time.sleep'):
            return sources.RestClient().agg_trades(SYMBOL, from_id=100)

    def test_rest_to_database_to_bars_cvd_and_gap(self):
        seed = trade(100, 1, 2, False, 1000, 1001)
        payload = [trade(101, 2, .5, True, 1002),
                   trade(103, 3, 1, False, 1004),  # agg_id 102 missing
                   trade(104, 1800, 2, True, 1005, 1006),
                   trade(105, 1801, .5, False, 1007)]
        seed_result = db.insert_rows(self.conn, SYMBOL, self.rest_rows([seed]))
        self.assertEqual(seed_result['inserted'], 1)
        self.conn.commit()
        with patch('requests.sessions.Session.get', return_value=Response(payload)) as get, \
             patch('btcof.sources.time.sleep'):
            result = downloader.catch_up(self.conn, SYMBOL, until_ms=BASE + 3600000)
        # This test checks the arithmetic only, not whether the gap was safely handled.
        self.assertEqual(result['inserted'], 4)
        self.assertEqual(get.call_args.kwargs['params']['fromId'], 101)
        self.assertEqual(self.conn.execute('SELECT COUNT(*) FROM agg_trades').fetchone()[0], 5)
        # Replaying a batch is idempotent; the payload must be identical.
        replay = db.insert_rows(self.conn, SYMBOL, self.rest_rows(payload))
        self.assertEqual((replay['inserted'], replay['dupes'], replay['conflicts']), (0, 4, 0))
        self.conn.commit()
        report = gaps.continuity(self.conn, SYMBOL, 30)
        self.assertEqual((report['id_gap_events'], report['id_missing_total']), (1, 1))
        self.assertEqual((report['id_gap_examples'][0]['after_id'],
                          report['id_gap_examples'][0]['next_id']), (101, 103))
        built = cvd.rebuild(self.conn, SYMBOL, 30, persist=True)
        self.assertEqual(built['status'], 'ok')
        bars = db.fetch_bars(self.conn, SYMBOL, 30)
        self.assertEqual(len(bars), 2)
        expected = [dict(buy_vol=3, sell_vol=.5, delta=2.5,
                         delta_pct=2.5/3.5*100, cvd_open=0, cvd_close=2.5),
                    dict(buy_vol=.5, sell_vol=2, delta=-1.5,
                         delta_pct=-1.5/2.5*100, cvd_open=2.5, cvd_close=1)]
        for bar, want in zip(bars, expected):
            for key, value in want.items():
                self.assertAlmostEqual(bar[key], value, places=9, msg=key)
        self.assertAlmostEqual(built['cvd'], 1)
        self.assertEqual(db.load_checkpoint(self.conn, SYMBOL, 30)['last_agg_id'], 105)

    def test_rest_must_not_write_beyond_id_gap(self):
        db.insert_rows(self.conn, SYMBOL, self.rest_rows([trade(100, 1, 1, False, 1000)]))
        self.conn.commit()
        payload = [trade(101, 2, 1, False, 1001), trade(103, 3, 1, False, 1003)]
        with patch('requests.sessions.Session.get', return_value=Response(payload)), patch('btcof.sources.time.sleep'):
            result = downloader.catch_up(self.conn, SYMBOL, until_ms=BASE + 3600000)
        stored = [row[0] for row in self.conn.execute('SELECT agg_id FROM agg_trades ORDER BY agg_id')]
        self.assertNotIn(103, stored, 'id 103 was persisted beyond missing id 102; result=%r' % result)

    def test_backfilled_prior_bar_must_invalidate_checkpoint(self):
        # Backfill into an earlier bar after a checkpoint is saved. Continue
        # must signal stale (or rebuild correctly), not silently use old CVD.
        initial = [trade(100, 1, 2, False, 1000),
                   trade(102, 1801, 2, True, 1002)]
        db.insert_rows(self.conn, SYMBOL, self.rest_rows(initial))
        self.conn.commit()
        self.assertAlmostEqual(cvd.rebuild(self.conn, SYMBOL, 30)['cvd'], 0)
        db.insert_rows(self.conn, SYMBOL, self.rest_rows([trade(101, 2, 1, False, 1001)]))
        self.conn.commit()
        continued = cvd.continue_(self.conn, SYMBOL, 30, persist=False)
        rebuilt = cvd.rebuild(self.conn, SYMBOL, 30, persist=False)
        self.assertTrue(continued['status'] == 'stale' or
                        abs(continued['cvd'] - rebuilt['cvd']) < 1e-9,
                        'backfill undetected: continue=%r, rebuild=%r' %
                        (continued['cvd'], rebuilt['cvd']))

    def test_rest_must_reject_invalid_negative_quantity(self):
        # Transport and database are genuine production paths; invalid rows
        # should be rejected rather than stored and corrupting order flow.
        with self.assertRaises((schema.SchemaError, ValueError)):
            rows = self.rest_rows([trade(100, 1, -2, False, 1000)])
            db.insert_rows(self.conn, SYMBOL, rows)


if __name__ == '__main__':
    unittest.main(verbosity=2)

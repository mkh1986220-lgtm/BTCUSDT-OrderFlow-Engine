# VERIFICATION CORRECTION — NOT FINAL / NOT PRODUCTION READY

This notebook revision found three failing production-path integration tests. The descriptions below of integrity.py refer to standalone helpers; they are NOT proof those protections are used by the CLI/collector. In particular, late backfill can yield stale CVD, catch_up can write past a hole and negative REST quantity can be accepted. See reports/TEST_REPORT_V12_VERIFICATION.txt and full cell log. The previous wording was overly broad.

Notebook rewritten for the delivered v1.2 ZIP; four synthetic integration tests added. No production source modules changed in this revision. Actual Colab execution remains unverified.

---
Historical changelog from the prior package (claims subject to the correction above):

# CHANGELOG — BTCUSDT Order Flow Engine v1.2

Base: v1.1.0 (unchanged, retrievable from the repository commit b373ca3).

## Added
- `btcof/integrity.py` — integrity layer, no strategy/signal code.
  - `invalidate_checkpoints` / `register_late_rows`: any late, corrected or
    backfilled aggTrade voids every checkpoint whose bar it can affect.
  - `cvd_status` → `CVD_VALID` / `CVD_INCOMPLETE` / `CVD_UNKNOWN`. CVD is never
    VALID while a gap, a partial/corrupt/missing archive day, a conflicting
    duplicate or an unresolved `gap:<symbol>` state exists.
  - `classify_day` / `archive_status`: three independent gap classes (missing
    archive file, aggTrade id gap, time/empty-bucket gap). Unknown and complete
    are separate states. A loaded day whose M30 buckets are incomplete is
    `partial`, not `ok`.
  - `contiguous_prefix` / `rest_backfill`: only the unbroken run starting at
    `next_id` is written; a hole stops the insert, records `GAP_UNRESOLVED`,
    leaves everything behind the hole unwritten and voids checkpoints.
  - `ws_delivery_ok`: HTTP 101 alone is not data.
  - `ws_recovery` / `reconnect_delays`: resume is only proven when REST covers
    the socket tail; otherwise `GAP_UNRESOLVED`. Capped exponential backoff.
  - `safe_ingest_day`: real resume (completed day skipped), retryable
    `FILE NOT PUBLISHED` / `SCHEMA ERROR` / `EMPTY FILE` / `PARTIAL`, single
    transaction per file (failure writes nothing), additive ingest_log so a
    re-run never wipes earlier statistics.
  - `http_ok`: 403/418/429/451/5xx and empty bodies raise instead of becoming
    an empty valid response.
  - `pagination_verdict`: incomplete pagination → `INCOMPLETE`, unknown window
    → `UNDETERMINED`, never `OK`.
  - `validate_kline`: expected / missing / differing / invalid_rows counted
    separately, zero references handled, `OK` impossible with any defect.
  - `range_rows`: report counts limited to the requested window.
- `btcof/tests_v12.py` — 31 independent tests covering the 15 mandatory areas.

## Changed
- `btcof/__init__.py` version → 1.2.0.

## Not changed
- No trading strategy, entry/exit signal, SL/TP or risk management added.
- CVD formula, bar builder and existing v1.1 behaviour preserved; the 26 v1.1
  self-tests still run unchanged.
